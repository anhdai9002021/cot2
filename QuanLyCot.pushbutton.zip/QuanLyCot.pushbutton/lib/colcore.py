# -*- coding: utf-8 -*-
"""
colcore.py  -  phần lõi dùng chung cho tool cột (không phụ thuộc Revit / Windows Forms)

  - THIẾT LẬP (lưu JSON):  thép mặc định, công thức neo móng / neo dầm, neo đầu cột, quy tắc vẽ
  - QUY TẮC NEO CHÂN CỘT:  móng:  l = H - a      (mặc định a=150)
                            dầm đỡ: l = H - a      (mặc định a=100)
  - GOM CỘT theo Mark + vị trí mặt bằng, tách dạng khác nhau, tính SL
  - GHI FILE EXCEL đúng cấu trúc sheet 'Column Detail' (không cần openpyxl)
"""
import json
import math
import os
import re
import zipfile
from xml.sax.saxutils import escape

HERE = os.path.dirname(os.path.abspath(__file__))
ASSET_DIR = os.path.join(HERE, "data")          # C3.dxf, COLREBAR.lsp, dua_vao_cad.ps1

DEFAULT_SETTINGS = {
    # thép mặc định khi chưa nhập
    "nb": 2, "nh": 2, "dia": 18, "stir": "R8-100/200",
    "round_n": 8,                         # cột TRÒN: tổng số cây thép dọc mặc định
    # neo chân cột
    "found_a": 150,                       # cột trên móng:  l = H - found_a
    "beam_a": 100,                        # cột trên dầm :  l = H - beam_a
    "base_default": "600/400",            # khi không tìm thấy móng / dầm (H/L, mm)
    # neo đầu cột
    "head_k": 30,                         # đầu cột có dầm: neo head_k x d ; không có dầm: kéo thẳng
    # quy tắc vẽ
    "lap_k": 40, "hook": 300, "min_mid": 500, "dense_div": 4, "round_step": 50, "round_mode": "up",
    # cấu tạo (mm)
    "cover": 30, "bar_inset": 50, "stir_hook_k": 6, "jog": 100, "jog_x": 30, "stirrup_end": 50, "top_cover": 30,
    # tên tham số Revit thêm (cách nhau dấu phẩy) + nhật ký
    "names_b": "", "names_h": "", "names_dia": "", "names_bw": "", "names_bh": "", "debug_log": 0,
    # bố cục bản vẽ / bảng thống kê (v9: trước đây cố định trong code)
    "col_step": 8000,                     # khoảng cách giữa các cột khi vẽ nhiều cột (mm)
    "table_rows": 40,                     # số dòng thống kê tối đa / 1 phần bảng
    "bar_std": 11.7,                      # chiều dài cây thép tiêu chuẩn (m)
    "coil_max_d": 8,                      # Ø <= giá trị này coi là thép cuộn (không chia cây)
    # v9.5: dò móng / dầm (có thể chỉnh nếu model dựng khác thông lệ)
    "tol_base": 120,                      # mm: mặt trên móng / dầm đỡ lệch cao độ chân cột <= giá trị này vẫn nhận
    "tol_top": 100,                       # mm: dầm đầu cột lệch cao độ đỉnh cột <= giá trị này vẫn nhận
    "max_beam": 1500,                     # mm: "dầm" cao hơn mức này (vách, thang...) bị loại
    # v9.5: thép bổ sung (tầng trên nhiều thanh hơn tầng dưới) + đai xoắn cột tròn
    "add_anchor_k": 40,                   # thép bổ sung neo xuống cột tầng dưới: add_anchor_k x d
    "stir_round": "",                     # đai mặc định cột TRÒN (để trống = dùng đai chung). Đai xoắn: S10-100/200
    "spiral_end": 1.5,                    # đai xoắn: số vòng đai kín ở mỗi đầu
    # gộp cột cùng Mark khác chiều cao (0=tách riêng, 1=hỏi chọn khi quét, 2=tự lấy cột cao nhất)
    "merge_same_mark": 0,
    # giao diện
    "theme": "light",
}

INT_KEYS = ("nb", "nh", "dia", "round_n", "found_a", "beam_a", "head_k", "lap_k", "hook", "min_mid",
            "dense_div", "round_step",
            "cover", "bar_inset", "stir_hook_k", "jog", "jog_x", "stirrup_end", "top_cover", "debug_log",
            "col_step", "table_rows", "coil_max_d", "tol_base", "tol_top", "max_beam", "add_anchor_k",
            "merge_same_mark")
FLOAT_KEYS = ("bar_std", "spiral_end")


def settings_path():
    base = os.environ.get("APPDATA") or os.path.expanduser("~")
    d = os.path.join(base, "CotTools")
    try:
        os.makedirs(d, exist_ok=True)
    except Exception:
        d = HERE
    return os.path.join(d, "settings.json")


def load_settings():
    st = dict(DEFAULT_SETTINGS)
    try:
        with open(settings_path(), "r", encoding="utf-8") as f:
            data = json.load(f)
        for k, v in data.items():
            if k in st:
                st[k] = v
    except Exception:
        pass
    return st


def save_settings(st):
    try:
        with open(settings_path(), "w", encoding="utf-8") as f:
            json.dump(st, f, ensure_ascii=False, indent=1)
        return True
    except Exception:
        return False


# ----------------------------------------------------------------------------
# Tuỳ chọn khi vẽ ra CAD (nhớ lần chọn trước)
# ----------------------------------------------------------------------------
DEFAULT_DRAW_OPTS = {"base_splice": False, "top_through": True, "thru_len": 1000}


def draw_opts_path():
    return os.path.join(os.path.dirname(settings_path()), "draw_opts.json")


def load_draw_opts():
    o = dict(DEFAULT_DRAW_OPTS)
    try:
        with open(draw_opts_path(), "r", encoding="utf-8") as f:
            data = json.load(f)
        for k in o:
            if k in data:
                o[k] = data[k]
        o["thru_len"] = int(float(o["thru_len"]))
        o["base_splice"] = bool(o["base_splice"])
        o["top_through"] = bool(o["top_through"])
    except Exception:
        o = dict(DEFAULT_DRAW_OPTS)
    return o


def save_draw_opts(o):
    try:
        with open(draw_opts_path(), "w", encoding="utf-8") as f:
            json.dump(o, f, ensure_ascii=False, indent=1)
        return True
    except Exception:
        return False


def apply_draw_opts(E, o):
    """Đẩy tuỳ chọn chân cột / tầng mái thấp vào bộ vẽ."""
    E.BASE_SPLICE = bool(o["base_splice"])
    E.TOP_THROUGH = bool(o["top_through"])
    E.THRU_MIN_LEN = float(o["thru_len"])


def clean_settings(raw):
    """Chuẩn hoá giá trị người dùng nhập (chuỗi -> số). Trả về (settings, lỗi)."""
    st = dict(DEFAULT_SETTINGS)
    errs = []
    for k, dv in DEFAULT_SETTINGS.items():
        v = raw.get(k, dv)
        if k in INT_KEYS:
            try:
                st[k] = int(round(float(str(v).replace(",", "."))))
            except ValueError:
                errs.append("'%s' phải là số" % k)
                st[k] = dv
        elif k in FLOAT_KEYS:
            try:
                st[k] = float(str(v).replace(",", "."))
            except ValueError:
                errs.append("'%s' phải là số" % k)
                st[k] = dv
        else:
            st[k] = str(v).strip() if v is not None else dv
    if not re.search(r"\d+\s*[-aA]\s*\d+", st["stir"]):
        errs.append("Đai mặc định sai dạng (ví dụ R8-100/200)")
        st["stir"] = DEFAULT_SETTINGS["stir"]
    if len(re.findall(r"\d+", st["base_default"])) < 2:
        errs.append("Móng mặc định phải dạng H/L (ví dụ 600/400)")
        st["base_default"] = DEFAULT_SETTINGS["base_default"]
    for k_, lo_, lb_ in (("round_n", 4, "Số cây thép cột tròn phải >= 4"),
                         ("col_step", 3000, "Khoảng cách giữa các cột (mm) phải >= 3000"),
                         ("table_rows", 5, "Số dòng / phần bảng thống kê phải >= 5"),
                         ("bar_std", 1, "Chiều dài cây thép chuẩn (m) phải >= 1"),
                         ("coil_max_d", 0, "Ø thép cuộn tối đa không được âm")):
        if st[k_] < lo_:
            errs.append(lb_)
            st[k_] = DEFAULT_SETTINGS[k_]
    for k_, lo_, hi_, lb_ in (("tol_base", 10, 600, "Dung sai chân cột phải trong 10..600 mm"),
                              ("tol_top", 10, 600, "Dung sai đỉnh cột phải trong 10..600 mm"),
                              ("max_beam", 300, 5000, "Cao dầm tối đa phải trong 300..5000 mm"),
                              ("add_anchor_k", 10, 80, "Neo thép bổ sung phải trong 10..80 x d")):
        if not (lo_ <= st[k_] <= hi_):
            errs.append(lb_)
            st[k_] = DEFAULT_SETTINGS[k_]
    if not (0.0 <= st["spiral_end"] <= 4.0):
        errs.append("Số vòng đai kín đầu đai xoắn phải trong 0..4")
        st["spiral_end"] = DEFAULT_SETTINGS["spiral_end"]
    if st["stir_round"] and not re.search(r"\d+\s*[-aA]\s*\d+", st["stir_round"]):
        errs.append("Đai cột tròn sai dạng (ví dụ S10-100/200 hoặc R8-100/200), hoặc để trống")
        st["stir_round"] = ""
    if st["round_mode"] not in ("up", "nearest"):
        st["round_mode"] = "up"
    if st["theme"] not in ("light", "dark"):
        st["theme"] = "light"
    if st["merge_same_mark"] not in (0, 1, 2):
        st["merge_same_mark"] = 0
    return st, errs


def apply_engine_settings(E, st):
    """Đẩy thiết lập vào bộ vẽ (excel_to_dxf)."""
    E.LAP_K = float(st["lap_k"])
    E.HOOK = float(st["hook"])
    E.MIN_MID = float(st["min_mid"])
    E.DENSE_DIV = float(st["dense_div"])
    E.ROUND_STEP = float(st["round_step"])
    E.ROUND_MODE = st["round_mode"]
    E.HEAD_ANCHOR_K = float(st["head_k"])
    E.COVER = float(st["cover"])
    E.BAR_INSET = float(st["bar_inset"])
    E.STIR_HOOK_K = float(st["stir_hook_k"])
    E.JOG = float(st["jog"])
    E.JOG_X = float(st["jog_x"])
    E.STIRRUP_END = float(st["stirrup_end"])
    E.TOP_COVER = float(st["top_cover"])
    E.COL_STEP = float(st["col_step"])
    E.ADD_ANCHOR_K = float(st["add_anchor_k"])
    E.SPIRAL_END_TURNS = float(st["spiral_end"])


def apply_table_settings(BT, st):
    """Đẩy thiết lập vào bộ vẽ bảng thống kê (bang_thong_ke). MAX_ROWS phải truyền tường minh khi gọi BT.generate."""
    BT.BAR_STD = float(st["bar_std"])
    BT.COIL_MAX_D = int(st["coil_max_d"])
    BT.MAX_ROWS = int(st["table_rows"])


# ----------------------------------------------------------------------------
# Đai xoắn / đai mặc định theo dạng cột / tên Mark an toàn
# ----------------------------------------------------------------------------
def is_spiral(stir):
    """Đai xoắn khi chuỗi đai bắt đầu bằng S / X (S10-100/200) hoặc có chữ 'xoắn' / 'xoan' / 'spiral'."""
    t = str(stir or "").strip().lower()
    return bool(re.match(r"^[sx]\s*\d", t)) or ("xoắn" in t) or ("xoan" in t) or ("spiral" in t)


def default_stir(st, shape):
    """Đai mặc định: cột tròn dùng st['stir_round'] nếu có, còn lại dùng đai chung."""
    if shape == "round" and str(st.get("stir_round") or "").strip():
        return st["stir_round"].strip()
    return st["stir"]


def safe_mark(m):
    """Mark ghi vào DXF (XDATA dùng '|' và '=' làm ký tự phân cách) -> thay ký tự cấm."""
    return str(m).replace("|", "/").replace("=", "-").strip()


# ----------------------------------------------------------------------------
# Quy tắc neo chân cột
# ----------------------------------------------------------------------------
def base_text(kind, H, st):
    """Chuỗi 'H/L' (cột Y của Excel).  kind: 'found' (móng) | 'beam' (dầm đỡ) | None."""
    if kind == "found" and H:
        L = max(int(round(H)) - st["found_a"], 0)
        return "%d/%d" % (round(H), L)
    if kind == "beam" and H:
        L = max(int(round(H)) - st["beam_a"], 0)
        return "%d/%d" % (round(H), L)
    return st["base_default"]


def base_kind_label(kind):
    return {"found": "Móng", "beam": "Dầm đỡ"}.get(kind or "", "Mặc định")


# ----------------------------------------------------------------------------
# Gom cột theo Mark
# ----------------------------------------------------------------------------
TOL_XY = 150.0      # mm: cùng Mark & cách nhau <= giá trị này = cùng 1 cột đứng
TOL_Z = 20.0        # mm: đỉnh đoạn dưới trùng đáy đoạn trên = liên tục


def nat_key(s):
    return [int(t) if t.isdigit() else t.lower() for t in re.split(r"(\d+)", str(s))]


def build_rows(items, st):
    """items: mỗi cột (1 instance Revit) = dict: mark, x, y, base_name, top_name, base_z, top_z (mm),
       b, h, R (cao dầm đầu cột, mm hoặc None), S ('WxD' hoặc ''), support (None | ('found'|'beam', H_mm)).
       Trả về (rows, warns). Mỗi row = 1 đoạn cột (1 dòng Column Detail), đã điền thép mặc định."""
    warns = []
    nosup, slants = [], []
    by_mark = {}
    for it in items:
        it["mark"] = safe_mark(it["mark"])
        by_mark.setdefault(it["mark"], []).append(it)
    rows = []
    for mark in sorted(by_mark, key=nat_key):
        lst = sorted(by_mark[mark], key=lambda i: (i["base_z"], i["top_z"]))
        clusters = []
        for it in lst:
            x, y = it.get("x"), it.get("y")
            target = None
            if x is None:
                target = clusters[0] if clusters else None
            else:
                for cl in clusters:
                    if cl["x"] is not None and math.hypot(cl["x"] - x, cl["y"] - y) <= TOL_XY:
                        target = cl
                        break
            if target is None:
                target = dict(x=x, y=y, items=[])
                clusters.append(target)
            target["items"].append(it)
        stacks = []
        for cl in clusters:
            segs = sorted(cl["items"], key=lambda i: (i["base_z"], i["top_z"]))
            cur = [segs[0]]
            for sg in segs[1:]:
                if abs(sg["base_z"] - cur[-1]["top_z"]) <= TOL_Z:
                    cur.append(sg)
                else:
                    stacks.append(cur)
                    cur = [sg]
            stacks.append(cur)

        def sig(stk):
            return tuple((q["base_name"], q["top_name"], int(round(q["base_z"])), int(round(q["top_z"])),
                          int(round(q["b"])) if q["b"] else 0, int(round(q["h"])) if q["h"] else 0,
                          q.get("shape", "rect"), int(round(q.get("slant") or 0))) for q in stk)
        groups = {}
        for stk in stacks:
            groups.setdefault(sig(stk), []).append(stk)
        order = sorted(groups, key=lambda g: (-len(groups[g]), groups[g][0][0]["base_z"]))
        if len(order) > 1:
            warns.append("%s: có %d dạng cột khác nhau (khác tầng hoặc kích thước) -> tách thành %s. "
                         "Nên đặt Mark khác nhau trong Revit." % (
                             mark, len(order), ", ".join([mark] + ["%s-%d" % (mark, i + 1) for i in range(1, len(order))])))
        for gi, g in enumerate(order):
            name = mark if gi == 0 else "%s-%d" % (mark, gi + 1)
            reps = groups[g]
            rep = reps[0]
            for idx, seg in enumerate(rep):
                b, h = seg["b"], seg["h"]
                if not b or not h:
                    warns.append("%s (%s → %s): không đọc được kích thước b/h, hãy nhập tay" % (
                        name, seg["base_name"], seg["top_name"]))
                Rv = next((q[idx]["R"] for q in reps if q[idx].get("R")), None)
                Sv = next((q[idx]["S"] for q in reps if q[idx].get("S")), "")
                sup = next((q[idx].get("support") for q in reps if idx == 0 and q[idx].get("support")), None)
                kind, Hs = (sup if sup else (None, None))
                slant = float(seg.get("slant") or 0.0)
                if slant > 0 and seg.get("axis_len"):
                    H_row = round(seg["axis_len"] / 1000.0, 3)          # cột xiên: H = chiều dài TRỤC
                else:
                    H_row = round((seg["top_z"] - seg["base_z"]) / 1000.0, 3)
                row = dict(
                    mark=name, n_from=seg["base_name"], n_to=seg["top_name"],
                    H=H_row, Hz=round((seg["top_z"] - seg["base_z"]) / 1000.0, 3),
                    slant=(round(slant, 1) if slant > 0 else None),
                    b=int(round(b)) if b else None, h=int(round(h)) if h else None,
                    nb=(st["round_n"] if seg.get("shape") == "round" else st["nb"]),
                    nh=(None if seg.get("shape") == "round" else st["nh"]),
                    shape=("round" if seg.get("shape") == "round" else "rect"),
                    dia=st["dia"], stir=default_stir(st, "round" if seg.get("shape") == "round" else "rect"),
                    R=int(round(Rv)) if Rv else None, S=Sv,
                    X=round(seg["base_z"] / 1000.0, 3) if idx == 0 else None,
                    Y=base_text(kind, Hs, st) if idx == 0 else None,
                    base_kind=(kind or "") if idx == 0 else "", base_H=(Hs or 0) if idx == 0 else 0,
                    SL=len(reps) if idx == 0 else None,
                    base_mark=mark,
                    col_id=seg.get("id"))
                if idx == 0 and not kind:
                    nosup.append(name)
                if slant > 0:
                    slants.append("%s (%g°)" % (name, round(slant, 1)))
                rows.append(row)
    for i, r in enumerate(rows):
        r["row"] = 9 + i
    if nosup:
        warns.append("%d Mark KHÔNG dò được móng / dầm đỡ dưới chân cột -> dùng neo mặc định %s (ô 'Móng / neo' tô vàng): %s. "
                     "Kiểm tra trong Revit (cao độ mặt móng / dầm so với chân cột, Dung sai trong Thiết lập) hoặc nhập tay."
                     % (len(nosup), st["base_default"], ", ".join(nosup[:20]) + (" ..." if len(nosup) > 20 else "")))
    if slants:
        warns.append("CỘT XIÊN: %s. Thép / đai tính theo chiều dài TRỤC cột; tool KHÔNG tự dò dầm đầu cột và móng / dầm đỡ "
                     "cho cột xiên -> nhập tay cột 'Dầm đầu cột' và 'Móng / neo'. Hình vẽ thể hiện cột theo chiều dài trục."
                     % ", ".join(slants[:20]))
    return rows, warns


def recompute_base(rows, st):
    """Tính lại cột Y (H/L) theo thiết lập hiện tại cho các dòng đã dò được móng / dầm."""
    n = 0
    for r in rows:
        if r.get("Y") is not None and r.get("base_kind"):
            r["Y"] = base_text(r["base_kind"], r.get("base_H"), st)
            n += 1
    return n


# ----------------------------------------------------------------------------
# Quản lý theo Mark (dùng cho lưới chỉnh sửa)
# ----------------------------------------------------------------------------
STEEL_KEYS = ("nb", "nh", "dia", "stir")


def marks_in_order(rows):
    seen, out = set(), []
    for r in rows:
        if r["mark"] not in seen:
            seen.add(r["mark"])
            out.append(r["mark"])
    return out


def fill_defaults(rows, st, only_empty=True, marks=None):
    """Điền thép mặc định. only_empty=True chỉ điền ô trống. marks: giới hạn theo Mark (None = tất cả)."""
    n = 0
    for r in rows:
        if marks is not None and r["mark"] not in marks:
            continue
        for k in STEEL_KEYS:
            rnd = r.get("shape") == "round"
            if rnd and k == "nh":
                continue                                   # cột tròn: chỉ có TỔNG số cây (ô 'Cây cạnh b')
            empty = r.get(k) in (None, "", 0)
            if empty or not only_empty:
                r[k] = st["round_n"] if (rnd and k == "nb") else (default_stir(st, "round" if rnd else "rect") if k == "stir" else st[k])
                n += 1
    return n


def copy_steel_to_mark(rows, index):
    """Chép thép (số cây, Ø, đai) của dòng index cho tất cả dòng cùng Mark. Trả về số dòng được chép."""
    src = rows[index]
    n = 0
    for i, r in enumerate(rows):
        if i != index and r["mark"] == src["mark"]:
            for k in STEEL_KEYS:
                r[k] = src[k]
            n += 1
    return n


def missing_fields(r):
    """Danh sách khoá còn thiếu / không hợp lệ của 1 dòng (để tô vàng trên lưới)."""
    miss = []
    rnd = r.get("shape") == "round"
    for k in ("b", "h", "nb", "nh", "dia"):
        if rnd and k in ("h", "nh"):
            continue                                       # cột tròn: b = h = đường kính, nh không dùng
        v = r.get(k)
        if v in (None, "") or (isinstance(v, (int, float)) and v <= 0):
            miss.append(k)
    if not re.search(r"\d+\s*[-aA]\s*\d+", str(r.get("stir") or "")):
        miss.append("stir")
    # neo chân cột đang dùng giá trị MẶC ĐỊNH (không dò được móng / dầm và chưa nhập tay) -> tô vàng để kiểm tra
    if r.get("X") is not None and r.get("Y") is not None and not r.get("base_kind") and "Y" not in (r.get("manual") or []):
        miss.append("Y")
    return miss


def group_index(rows):
    """Chỉ số nhóm (0,1,2,...) theo Mark để tô màu xen kẽ."""
    out, g, last = [], -1, None
    for r in rows:
        if r["mark"] != last:
            g += 1
            last = r["mark"]
        out.append(g)
    return out


# ----------------------------------------------------------------------------
# Gộp cột cùng Mark khác chiều cao: chọn 1 cột triển khai & cộng dồn SL
# ----------------------------------------------------------------------------
def column_variants(rows):
    """Nhóm các dòng liên tiếp cùng 'mark' thành danh sách biến thể cột."""
    variants = []
    cur_mark = None
    cur_rows = []
    cur_idx = []
    for idx, r in enumerate(rows):
        if r["mark"] != cur_mark:
            if cur_rows:
                variants.append(_make_variant(cur_rows, cur_idx))
            cur_mark = r["mark"]
            cur_rows = [r]
            cur_idx = [idx]
        else:
            cur_rows.append(r)
            cur_idx.append(idx)
    if cur_rows:
        variants.append(_make_variant(cur_rows, cur_idx))
    return variants


def _make_variant(segs, indices):
    r0, rk = segs[0], segs[-1]
    mk = r0["mark"]
    bm = r0.get("base_mark")
    if not bm:
        bm = re.sub(r"-\d+$", "", mk)
    lv = ("%s → %s" % (r0.get("n_from") or "", rk.get("n_to") or "")) if (r0.get("n_from") != rk.get("n_to")) else (r0.get("n_from") or "")
    tot_h = round(sum(float(r.get("H") or 0.0) for r in segs), 3)
    sz = ("Ø%s" % (r0.get("b") or "?")) if r0.get("shape") == "round" else ("%s×%s" % (r0.get("b") or "?", r0.get("h") or "?"))
    try:
        sl = max(int(r0.get("SL") or 1), 1)
    except Exception:
        sl = 1
    return {
        "mark": mk,
        "base_mark": bm,
        "rows": segs,
        "indices": indices,
        "levels": lv,
        "total_H": tot_h,
        "size": sz,
        "sl": sl,
        "n_segs": len(segs),
    }


def same_mark_groups(rows):
    """Trả về [(base_mark, [variant, ...]), ...] cho các Mark có >= 2 biến thể (vd C1, C1-2...)."""
    variants = column_variants(rows)
    all_marks = {v["mark"] for v in variants}
    by_bm = {}
    order = []
    for v in variants:
        bm = v["rows"][0].get("base_mark")
        if not bm:
            cand = re.sub(r"-\d+$", "", v["mark"])
            bm = cand if (cand != v["mark"] and cand in all_marks) else v["mark"]
            v["base_mark"] = bm
        if bm not in by_bm:
            by_bm[bm] = []
            order.append(bm)
        by_bm[bm].append(v)
    return [(bm, by_bm[bm]) for bm in order if len(by_bm[bm]) >= 2]


def merge_variants(rows, rep_mark, merged_marks, target_mark=None):
    """Gộp các biến thể trong merged_marks vào cột đại diện rep_mark và cộng dồn SL.
    Trả về (new_rows, info_dict)."""
    variants = column_variants(rows)
    merged = set(merged_marks or [])
    merged.add(rep_mark)
    rep_v = next((v for v in variants if v["mark"] == rep_mark), None)
    if rep_v is None:
        raise ValueError("Không tìm thấy cột đại diện '%s'" % rep_mark)
    sel_vars = [v for v in variants if v["mark"] in merged]
    total_sl = sum(v["sl"] for v in sel_vars)
    remaining_marks = {v["mark"] for v in variants if v["mark"] not in merged}
    want = (target_mark or "").strip()
    if want and want not in remaining_marks:
        final_mark = want
    else:
        final_mark = rep_mark
    new_rows = []
    for v in variants:
        if v["mark"] == rep_mark:
            for idx, r in enumerate(v["rows"]):
                rc = dict(r)
                rc["mark"] = final_mark
                if idx == 0:
                    rc["SL"] = total_sl
                new_rows.append(rc)
        elif v["mark"] not in merged:
            for r in v["rows"]:
                new_rows.append(dict(r))
    for i, r in enumerate(new_rows):
        r["row"] = 9 + i
    return new_rows, {
        "final_mark": final_mark,
        "rep_mark": rep_mark,
        "total_sl": total_sl,
        "merged_count": len(sel_vars),
        "total_H": rep_v["total_H"],
        "removed": [v["mark"] for v in sel_vars if v["mark"] != rep_mark],
    }


def auto_merge_tallest(rows):
    """Tự động gộp mọi nhóm cùng Mark khác chiều cao về biến thể cao nhất (nếu bằng cao thì lấy SL lớn hơn)."""
    cur = list(rows)
    summaries = []
    for bm, grp in same_mark_groups(cur):
        rep = max(grp, key=lambda v: (v["total_H"], v["sl"]))
        cur, info = merge_variants(cur, rep["mark"], [v["mark"] for v in grp], target_mark=bm)
        summaries.append(info)
    return cur, summaries


# ----------------------------------------------------------------------------
# Chuyển đổi dữ liệu <-> ô lưới
# ----------------------------------------------------------------------------
GRID_COLS = [  # (khoá, tiêu đề, chỉ đọc, kiểu, độ rộng)
    ("mark", "Mark", True, "s", 70), ("n_from", "Tầng đầu", True, "s", 90), ("n_to", "Tầng cuối", True, "s", 90),
    ("shape", "Dạng", False, "t", 76),
    ("H", "H (m)", True, "f", 62), ("slant", "Xiên (°)", True, "f", 62), ("b", "b (mm)", False, "i", 62), ("h", "h (mm)", False, "i", 62),
    ("nb", "Cây cạnh b", False, "i", 78), ("nh", "Cây cạnh h", False, "i", 78), ("dia", "Ø (mm)", False, "i", 60),
    ("stir", "Đai", False, "s", 110), ("R", "Dầm đầu cột (mm)", False, "i", 110), ("S", "Dầm giao", False, "s", 84),
    ("Y", "Móng / neo (H/L)", False, "s", 112), ("base_kind", "Đỡ bởi", True, "k", 80), ("SL", "SL", False, "i", 46),
]


MANUAL_KEYS = ("R", "S", "Y")      # ô do người dùng nhập / chọn tay (giữ lại khi quét lại nếu chọn)


def mark_manual(r, *keys):
    man = list(r.get("manual") or [])
    for k in keys:
        if k not in man:
            man.append(k)
    r["manual"] = man


def carry_over(old, new):
    """Quét lại: chép thép (số cây, Ø, đai), ô R / S / Y đã nhập tay và b / h (nếu Revit không đọc được)
    từ bảng cũ sang bảng mới cho các dòng trùng khớp (theo Id cột Revit, nếu không thì theo Mark + tầng).
    Trả về số dòng được giữ lại."""
    by_id = {r["col_id"]: r for r in old if r.get("col_id")}
    by_key = {(r["mark"], r["n_from"], r["n_to"]): r for r in old}
    n = 0
    for r in new:
        o = by_id.get(r.get("col_id")) or by_key.get((r["mark"], r["n_from"], r["n_to"]))
        if o is None:
            continue
        if o.get("shape", "rect") != r.get("shape", "rect"):
            continue                                       # đổi dạng cột (vuông <-> tròn): không chép thép cũ
        for k in STEEL_KEYS:
            if o.get(k) not in (None, ""):
                r[k] = o[k]
        for k in ("b", "h"):
            if r.get(k) in (None, "") and o.get(k) not in (None, ""):
                r[k] = o[k]
        man = list(o.get("manual") or [])
        for k in man:
            if k in ("R", "S"):
                r[k] = o.get(k)
            elif k == "Y" and r.get("Y") is not None and o.get("Y") is not None:
                r["Y"] = o["Y"]
                r["base_kind"] = o.get("base_kind", "")
                r["base_H"] = o.get("base_H", 0)
        r["manual"] = man
        if not r.get("base_mark") and o.get("base_mark"):
            r["base_mark"] = o["base_mark"]
        n += 1
    return n


def apply_shape_to_mark(rows, index):
    """Đổi dạng (Tròn / Chữ nhật) của dòng index cho TẤT CẢ dòng cùng Mark (mọi tầng của cột). Trả về số dòng đã đổi."""
    src = rows[index]
    want = "Tròn" if src.get("shape") == "round" else "Chữ nhật"
    n = 0
    for i, r in enumerate(rows):
        if i != index and r["mark"] == src["mark"] and r.get("shape", "rect") != src.get("shape", "rect"):
            ok, _m = set_cell(r, "shape", want)
            n += 1 if ok else 0
    return n


def cell_text(r, key):
    if key == "shape":
        return "Tròn" if r.get("shape") == "round" else "Chữ nhật"
    v = r.get(key)
    if key == "base_kind":
        return base_kind_label(v) if r.get("Y") is not None else ""
    if v is None:
        return ""
    if key == "H":
        return "%.3f" % v
    if key == "slant":
        return "%g" % v
    return str(v)


def set_cell(r, key, text):
    """Ghi lại giá trị người dùng nhập vào dòng r. Trả về (ok, thông báo)."""
    typ = {k: t for k, _, _, t, _ in GRID_COLS}.get(key, "s")
    t = (text or "").strip()
    if key == "shape":
        tl = t.lower()
        if tl in ("tròn", "tron", "t", "round", "o"):
            d = r.get("b") or r.get("h")
            r["b"] = r["h"] = d
            r["shape"] = "round"
            if not r.get("nb") or r["nb"] < 4 or r.get("nh"):
                r["nb"] = DEFAULT_SETTINGS["round_n"]
            r["nh"] = None
            return True, ""
        if tl in ("chữ nhật", "chu nhat", "cn", "hcn", "vuông", "vuong", "v", "r", "rect"):
            r["shape"] = "rect"
            if not r.get("nh"):
                r["nb"], r["nh"] = 2, 2
            return True, ""
        return False, "Dạng nhập: Tròn hoặc Chữ nhật"
    if typ == "i":
        if t == "":
            r[key] = None
            if key in MANUAL_KEYS:
                mark_manual(r, key)
            return True, ""
        try:
            r[key] = int(round(float(t.replace(",", "."))))
        except ValueError:
            return False, "Phải nhập số"
        if r.get("shape") == "round" and key in ("b", "h"):
            r["b"] = r["h"] = r[key]                       # cột tròn: b = h = đường kính
        if key in MANUAL_KEYS:
            mark_manual(r, key)
        return True, ""
    if key == "stir" and t and not re.search(r"\d+\s*[-aA]\s*\d+", t):
        return False, "Đai nhập dạng R8-100/200"
    if key == "Y" and t and len(re.findall(r"\d+", t)) < 2:
        return False, "Nhập dạng H/L, ví dụ 600/400"
    if key == "S" and t and not re.search(r"\d+\s*[xX×]\s*\d+", t):
        return False, "Dầm giao nhập dạng 200x450"
    r[key] = t.replace("×", "x") if key == "S" else t
    if key == "Y":
        r["base_kind"] = ""         # nhập tay -> không còn tự động theo thiết lập
    if key in MANUAL_KEYS:
        mark_manual(r, key)
    return True, ""


# ----------------------------------------------------------------------------
# Ghi Excel đúng cấu trúc Column Detail (không cần openpyxl)
# ----------------------------------------------------------------------------
def _col_letter(n):
    s = ""
    while n:
        n, r = divmod(n - 1, 26)
        s = chr(65 + r) + s
    return s


def write_xlsx(path, rows, results=None):
    """results: {số dòng Excel: (thép dọc, thép đai, thép nối)} kg -> điền cột AB, AC, AD (Bóc tách khối lượng)."""
    cells = {}

    def put(r, c, v, s=0):
        cells[(r, c)] = (v, s)

    put(1, 1, "THÔNG SỐ TRIỂN KHAI BẢN VẼ CỘT", 3)
    put(3, 1, "Ô VÀNG: còn thiếu dữ liệu cần nhập.", 0)
    heads = {1: "Pier", 2: "Tầng đầu", 3: "Tầng cuối", 4: "Số tầng", 5: "H (m)", 6: "b (mm)", 7: "h (mm)",
             8: "Số cây cạnh b", 10: "Số cây cạnh h", 12: "đk (mm)", 13: "Đai (đk+kc)",
             18: "Cao dầm (mm)", 19: "KT dầm giao", 23: "không nối", 24: "Cao độ (m)",
             25: "H móng/L thép neo (mm)", 27: "SLCK", 31: "Dạng (Tròn: b = h = Ø, 'cây cạnh b' = tổng số cây)", 28: "Thép dọc (Kg)", 29: "Thép đai (Kg)", 30: "Thép nối (Kg)", 32: "Xiên (° so với phương đứng; H = chiều dài trục)"}
    for c, t in heads.items():
        put(6, c, t, 1)
    put(7, 8, "Lớp 1", 1)
    put(7, 10, "Lớp 1", 1)
    put(5, 28, "Bóc tách khối lượng", 1)
    r = 9
    last = 8
    for row in rows:
        rr = row.get("row") or r
        put(rr, 1, row["mark"])
        put(rr, 2, row["n_from"])
        put(rr, 3, row["n_to"])
        put(rr, 4, 1)
        put(rr, 5, row["H"])
        put(rr, 31, "Tròn" if row.get("shape") == "round" else "Chữ nhật")
        if row.get("slant"):
            put(rr, 32, row["slant"])
        for c, k in ((6, "b"), (7, "h"), (8, "nb"), (10, "nh"), (12, "dia")):
            v = row.get(k)
            if v in (None, ""):
                if row.get("shape") == "round" and k == "nh":
                    continue                               # cột tròn: không có cạnh h
                put(rr, c, None, 2)
            else:
                put(rr, c, v)
        if row.get("stir"):
            put(rr, 13, row["stir"])
        else:
            put(rr, 13, None, 2)
        if row.get("R"):
            put(rr, 18, row["R"])
        if row.get("S"):
            put(rr, 19, row["S"])
        if row.get("X") is not None:
            put(rr, 24, row["X"])
            put(rr, 25, row.get("Y") or "", 0 if row.get("Y") else 2)
            if row.get("SL") is not None:
                put(rr, 27, row["SL"])
        if results and rr in results:
            d, dai, noi = results[rr]
            put(rr, 28, round(d, 2), 4)
            put(rr, 29, round(dai, 2), 4)
            put(rr, 30, round(noi, 2), 4)
        last = max(last, rr)
        r = rr + 1
    if results:
        tr = last + 2
        put(tr, 1, "TỔNG (kg)", 1)
        for c in (28, 29, 30):
            L = _col_letter(c)
            put(tr, c, round(sum(v[c - 28] for v in results.values()), 2), 4)

    def cell_xml(rr, cc, v, s):
        ref = "%s%d" % (_col_letter(cc), rr)
        st = ' s="%d"' % s if s else ""
        if v is None:
            return '<c r="%s"%s/>' % (ref, st)
        if isinstance(v, (int, float)):
            return '<c r="%s"%s><v>%s</v></c>' % (ref, st, repr(v))
        return '<c r="%s"%s t="inlineStr"><is><t xml:space="preserve">%s</t></is></c>' % (ref, st, escape(str(v)))

    rows_xml = []
    for rr in sorted(set(k[0] for k in cells)):
        cs = "".join(cell_xml(rr, cc, *cells[(rr, cc)]) for cc in sorted(k[1] for k in cells if k[0] == rr))
        rows_xml.append('<row r="%d">%s</row>' % (rr, cs))
    widths = {1: 9, 2: 14, 3: 14, 4: 8, 5: 9, 6: 9, 7: 9, 8: 11, 9: 9, 10: 11, 11: 9, 12: 9, 13: 18,
              18: 14, 19: 14, 23: 10, 24: 11, 25: 20, 27: 8, 28: 14, 29: 14, 30: 14, 31: 22, 32: 26}
    cols_xml = "".join('<col min="%d" max="%d" width="%s" customWidth="1"/>' % (c, c, w)
                       for c, w in sorted(widths.items()))
    sheet = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
             '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
             '<sheetViews><sheetView workbookViewId="0"><pane ySplit="8" topLeftCell="A9" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>'
             '<cols>%s</cols><sheetData>%s</sheetData></worksheet>') % (cols_xml, "".join(rows_xml))
    styles = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
              '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
              '<numFmts count="1"><numFmt numFmtId="164" formatCode="0.00"/></numFmts>'
              '<fonts count="3"><font><sz val="10"/><name val="Arial"/></font>'
              '<font><b/><sz val="10"/><name val="Arial"/></font>'
              '<font><b/><sz val="14"/><name val="Arial"/></font></fonts>'
              '<fills count="4"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill>'
              '<fill><patternFill patternType="solid"><fgColor rgb="FFFFF2CC"/></patternFill></fill>'
              '<fill><patternFill patternType="solid"><fgColor rgb="FFD9E1F2"/></patternFill></fill></fills>'
              '<borders count="2"><border/><border><left style="thin"/><right style="thin"/><top style="thin"/><bottom style="thin"/></border></borders>'
              '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
              '<cellXfs count="5">'
              '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'
              '<xf numFmtId="0" fontId="1" fillId="3" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>'
              '<xf numFmtId="0" fontId="0" fillId="2" borderId="1" xfId="0" applyFill="1" applyBorder="1"/>'
              '<xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyFont="1"/>'
              '<xf numFmtId="164" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyBorder="1"/>'
              '</cellXfs>'
              '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>'
              '</styleSheet>')
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml",
                   '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                   '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
                   '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
                   '<Default Extension="xml" ContentType="application/xml"/>'
                   '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
                   '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
                   '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
                   '</Types>')
        z.writestr("_rels/.rels",
                   '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                   '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                   '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
                   '</Relationships>')
        z.writestr("xl/workbook.xml",
                   '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                   '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
                   'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
                   '<sheets><sheet name="Column Detail" sheetId="1" r:id="rId1"/></sheets></workbook>')
        z.writestr("xl/_rels/workbook.xml.rels",
                   '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                   '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                   '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>'
                   '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'
                   '</Relationships>')
        z.writestr("xl/styles.xml", styles)
        z.writestr("xl/worksheets/sheet1.xml", sheet)


def results_map(stat_rows):
    """Từ kết quả thống kê (thong_ke_thep.compute) -> {số dòng Excel: (dọc, đai, nối)}."""
    return {r["row"]: (r["doc"], r["dai"], r["noi"]) for r in stat_rows if r.get("row")}
