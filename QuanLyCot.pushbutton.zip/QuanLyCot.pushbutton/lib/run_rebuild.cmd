@echo off
rem Goi rebuild.py: uu tien Python di kem (thu muc python\ canh file nay), roi "py -3", roi "python".
set "HERE=%~dp0"
if exist "%HERE%python\python.exe" ( "%HERE%python\python.exe" "%HERE%rebuild.py" %* & exit /b )
where py >nul 2>nul && ( py -3 "%HERE%rebuild.py" %* & exit /b )
where python >nul 2>nul && ( python "%HERE%rebuild.py" %* & exit /b )
echo Khong tim thay Python. Chep Python embeddable vao thu muc "%HERE%python" hoac cai Python 3. > "%~2\log.txt"
echo ERR> "%~2\result.txt"
exit /b 9
