# -*- coding: utf-8 -*-
"""
revit_scan.py  -  quét cột kết cấu trong Revit (tách khỏi script.py từ v9.5 để dễ bảo trì / kiểm tra)

Không import Revit ở mức module: doc, uidoc, DB (Autodesk.Revit.DB) được truyền vào scan_revit().
Kết quả (items) là danh sách dict, đưa thẳng cho colcore.build_rows().

v9.5: - cột XIÊN được quét (trước đây bị bỏ qua): lấy 2 đầu trục, H = chiều dài trục, ghi độ nghiêng
      - dung sai dò móng / dầm (tol_base, tol_top, max_beam) đọc từ Thiết lập, không còn cố định trong code
      - lý do không dò được móng / dầm luôn được ghi vào cottools.log
      - cột chưa có Mark: gộp thành 1 cảnh báo
"""
import math


def pn_names(st, key, base):
    """Tên tham số Revit: danh sách người dùng thêm (Thiết lập) dò trước, rồi tới danh sách mặc định."""
    extra = [x.strip() for x in str(st.get(key, "")).split(",") if x.strip()]
    return extra + [b_ for b_ in base if b_ not in extra]


def scan_revit(doc, uidoc, DB, st, log, set_status=None, refresh=None, scope="auto"):
    """Quét cột kết cấu trong Revit. scope: auto = cột đang chọn (nếu có) hoặc cả model | sel = chỉ cột đang chọn | all = cả model.
    doc, uidoc: tài liệu Revit | DB: module Autodesk.Revit.DB | st: thiết lập (dict) | log: hàm ghi nhật ký
    set_status(text) / refresh(): gọi định kỳ để form không treo (tuỳ chọn). Trả (items, warns, src)."""
    BIC, BIP = DB.BuiltInCategory, DB.BuiltInParameter
    pn = lambda key, base: pn_names(st, key, base)
    NB = pn("names_b", ["b", "B", "Width", "Column Width", "Chiều rộng", "Rộng", "Bề rộng"])
    NH = pn("names_h", ["h", "H", "Depth", "Column Depth", "Chiều sâu", "Sâu", "Bề sâu"])
    NW = pn("names_bw", ["b", "B", "Width", "Beam Width", "Chiều rộng", "Rộng", "Bề rộng"])
    dlog = log if st.get("debug_log") else (lambda *a: None)     # log chi tiết từng cột chỉ khi bật trong Thiết lập

    def mm(v):
        return DB.UnitUtils.ConvertFromInternalUnits(v, DB.UnitTypeId.Millimeters)

    def is_cat(e, bic):
        try:
            return e.Category is not None and e.Category.BuiltInCategory == bic
        except Exception:
            try:
                return e.Category is not None and e.Category.Id.Value == int(bic)
            except Exception:
                return False

    def dim_param(elems, names):
        for src in elems:
            if src is None:
                continue
            for nm in names:
                try:
                    p = src.LookupParameter(nm)
                except Exception:
                    p = None
                if p is not None and p.HasValue and p.StorageType == DB.StorageType.Double:
                    v = p.AsDouble()
                    if v > 0:
                        return mm(v)
        return None

    def level_of(e, bip_lvl, bip_off):
        p = e.get_Parameter(bip_lvl)
        if p is None:
            return None, 0.0, 0.0
        lv = doc.GetElement(p.AsElementId())
        if lv is None:
            return None, 0.0, 0.0
        po = e.get_Parameter(bip_off)
        off = po.AsDouble() if po is not None else 0.0
        z_int = lv.Elevation + off
        try:
            z_proj = lv.ProjectElevation + off
        except Exception:
            z_proj = z_int
        return lv, z_int, z_proj

    ids = list(uidoc.Selection.GetElementIds())
    cols = [e for e in (doc.GetElement(i) for i in ids) if e is not None and is_cat(e, BIC.OST_StructuralColumns)]
    src = "cột đang chọn"
    if scope == "all":
        cols = []
    if not cols:
        cols = list(DB.FilteredElementCollector(doc).OfCategory(BIC.OST_StructuralColumns)
                    .WhereElementIsNotElementType())
        src = "toàn bộ model"
    framing_all = list(DB.FilteredElementCollector(doc).OfCategory(BIC.OST_StructuralFraming)
                       .WhereElementIsNotElementType())

    def is_beam(e):
        # bỏ giằng chéo (Brace), vì kèo... chỉ giữ dầm thật; nếu không đọc được thì giữ lại
        try:
            return e.StructuralType == DB.Structure.StructuralType.Beam
        except Exception:
            return True
    framing = [e for e in framing_all if is_beam(e)]
    log("quet: framing tong=%d, dam=%d" % (len(framing_all), len(framing)))

    # ---- chỉ mục không gian: quét model 1 lần, mỗi cột chỉ tra cứu ô lưới lân cận ----
    # (bản cũ: mỗi cột lại duyệt TOÀN BỘ dầm + tạo 2 FilteredElementCollector -> O(N x M),
    #  model lớn bị treo hàng chục giây, Revit "Not Responding")
    CELL = 5.0      # feet

    def build_index(elems, want_dir):
        recs, grid = [], {}
        for e in elems:
            try:
                bb = e.get_BoundingBox(None)
                if bb is None:
                    continue
                rec = dict(e=e, x0=bb.Min.X, y0=bb.Min.Y, z0=bb.Min.Z, x1=bb.Max.X, y1=bb.Max.Y, z1=bb.Max.Z,
                           d=None, w=-1)
                if want_dir:
                    loc = e.Location
                    if not isinstance(loc, DB.LocationCurve):
                        continue
                    c = loc.Curve
                    v = c.GetEndPoint(1).Subtract(c.GetEndPoint(0))
                    L = (v.X * v.X + v.Y * v.Y) ** 0.5
                    if L < 1e-6:
                        continue
                    rec["d"] = (v.X / L, v.Y / L)
                    p0 = c.GetEndPoint(0)
                    rec["seg"] = (p0.X, p0.Y, v.X, v.Y, L)
                    rec["slope"] = abs(v.Z) / L          # dầm xiên: hộp bao cao hơn nhiều so với tiết diện
                recs.append(rec)
                i = len(recs) - 1
                for gx in range(int(rec["x0"] // CELL), int(rec["x1"] // CELL) + 1):
                    for gy in range(int(rec["y0"] // CELL), int(rec["y1"] // CELL) + 1):
                        grid.setdefault((gx, gy), []).append(i)
            except Exception:
                continue
        return recs, grid

    def near(index, x0, y0, x1, y1):
        recs, grid = index
        seen, out = set(), []
        for gx in range(int(x0 // CELL), int(x1 // CELL) + 1):
            for gy in range(int(y0 // CELL), int(y1 // CELL) + 1):
                for i in grid.get((gx, gy), ()):
                    if i not in seen:
                        seen.add(i)
                        r = recs[i]
                        if r["x0"] <= x1 and r["x1"] >= x0 and r["y0"] <= y1 and r["y1"] >= y0:
                            out.append(r)
        return out

    log("quet: bat dau lap chi muc")
    found_idx = build_index(DB.FilteredElementCollector(doc).OfCategory(BIC.OST_StructuralFoundation)
                            .WhereElementIsNotElementType(), False)
    beam_idx = build_index(framing, True)
    col_idx = build_index(DB.FilteredElementCollector(doc).OfCategory(BIC.OST_StructuralColumns)
                          .WhereElementIsNotElementType(), False)
    log("quet: chi muc xong  mong=%d  dam=%d" % (len(found_idx[0]), len(beam_idx[0])))

    MM = 1.0 / 304.8
    TOL_TOP = float(st.get("tol_top", 100)) * MM      # dầm "ở đầu cột" nếu mặt dầm giao với cao độ đỉnh cột ± giá trị này (Thiết lập)
    TOL_BASE = float(st.get("tol_base", 120)) * MM    # mặt trên dầm/móng trùng cao độ chân cột (Thiết lập)
    MAX_BEAM = float(st.get("max_beam", 1500))        # mm: 'dầm' cao hơn mức này không phải dầm ngang (vách, thang...) -> bỏ qua
    geo_cache = {}

    def solids_of(el):
        """Khối hình học thật của phần tử (đã gồm cắt/nối)."""
        key = el.Id.Value if hasattr(el.Id, "Value") else el.Id.IntegerValue
        if key in geo_cache:
            return geo_cache[key]
        out = []
        try:
            opt = DB.Options()
            opt.ComputeReferences = False
            opt.DetailLevel = DB.ViewDetailLevel.Fine

            def walk(gobj):
                for o in gobj:
                    try:
                        if o.Volume > 1e-9:
                            out.append(o)
                            continue
                    except Exception:
                        pass
                    try:
                        walk(o.GetInstanceGeometry())
                    except Exception:
                        pass
            walk(el.get_Geometry(opt))
        except Exception as ex:
            log("solids_of loi: %s" % ex)
        geo_cache[key] = out
        return out

    def z_hits(solids, x, y, zlo, zhi):
        """Đoạn thẳng đứng tại (x,y): trả về các khoảng cao độ (z_dưới, z_trên) nằm TRONG khối."""
        hits = []
        try:
            line = DB.Line.CreateBound(DB.XYZ(x, y, zlo), DB.XYZ(x, y, zhi))
        except Exception:
            return hits
        sco = DB.SolidCurveIntersectionOptions()
        for sd in solids:
            try:
                res = sd.IntersectWithCurve(line, sco)
                for k in range(res.SegmentCount):
                    c = res.GetCurveSegment(k)
                    za, zb = c.GetEndPoint(0).Z, c.GetEndPoint(1).Z
                    hits.append((min(za, zb), max(za, zb)))
            except Exception:
                continue
        return hits

    def in_xy(q, x, y, tol=0.07):
        """Điểm dò (feet) nằm trong hộp bao mặt bằng của phần tử (cho phép sai 70 mm) - bỏ qua phép cắt solid tốn kém nếu không."""
        return q["x0"] - tol <= x <= q["x1"] + tol and q["y0"] - tol <= y <= q["y1"] + tol

    def col_extent(col, pt):
        bb = col.get_BoundingBox(None)
        if bb is None:
            return pt.X, pt.Y, 0.5, 0.5
        return (bb.Max.X + bb.Min.X) / 2.0, (bb.Max.Y + bb.Min.Y) / 2.0, \
            (bb.Max.X - bb.Min.X) / 2.0, (bb.Max.Y - bb.Min.Y) / 2.0

    def eff_depth(thick_ft, q):
        """Chiều cao tiết diện từ bề dày thẳng đứng (dầm dốc: chia 1/cos)."""
        sl = q.get("slope", 0.0) if q else 0.0
        return mm(thick_ft) / ((1.0 + sl * sl) ** 0.5)

    NHB = pn("names_bh", ["h", "H", "Height", "Beam Height", "Chiều cao", "Cao", "Bề cao", "d", "Depth"])

    def _id(e):
        return e.Id.Value if hasattr(e.Id, "Value") else e.Id.IntegerValue

    def beam_w(q):
        if q["w"] == -1:
            bm = q["e"]
            q["w"] = dim_param([bm, doc.GetElement(bm.GetTypeId())], NW)
        return q["w"]

    def beam_h(q):
        """Cao dầm theo tham số loại (h / Height / d ...), None nếu không đọc được."""
        if "hp" not in q:
            bm = q["e"]
            v = dim_param([bm, doc.GetElement(bm.GetTypeId())], NHB)
            q["hp"] = v if (v and 100.0 <= v <= MAX_BEAM) else None
        return q["hp"]

    def beam_flat(q):
        return q.get("slope", 0.0) <= 0.02

    def plan_rel(q, cx, cy, hx, hy):
        """Vị trí tâm cột so với trục dầm (feet): (ngoài đầu dầm, lệch ngang, nửa cột dọc trục, nửa cột ngang trục)."""
        p0x, p0y, vx, vy, L = q["seg"]
        dx, dy = vx / L, vy / L
        rx, ry = cx - p0x, cy - p0y
        sp = rx * dx + ry * dy
        return (max(0.0, -sp, sp - L), abs(rx * dy - ry * dx),
                hx * abs(dx) + hy * abs(dy), hx * abs(dy) + hy * abs(dx))

    def col_below(col, cx, cy, z_base):
        """Có cột khác ngay dưới chân cột (đỉnh cột dưới = chân cột này) -> cột này đứng trên cột, không đứng trên dầm."""
        me = _id(col)
        for r in near(col_idx, cx - 0.2, cy - 0.2, cx + 0.2, cy + 0.2):
            if _id(r["e"]) == me:
                continue
            if abs(r["z1"] - z_base) <= TOL_BASE and r["x0"] - 30 * MM <= cx <= r["x1"] + 30 * MM \
                    and r["y0"] - 30 * MM <= cy <= r["y1"] + 30 * MM:
                return True
        return False

    def support_under(col, pt, z_base, hs):
        """Trả về ((loại, H) hoặc None, danh sách chẩn đoán).
        1) Tia thẳng đứng xuyên khối thật (như cũ).  2) Dự phòng: móng/dầm có mặt trên (hộp bao) trùng chân cột
        và tâm cột nằm trong mặt bằng của nó (dùng khi cột/dầm bị join làm tia hụt)."""
        cx, cy, hx, hy = col_extent(col, pt)
        probes = [(cx, cy), (cx + 0.5 * hx, cy), (cx - 0.5 * hx, cy), (cx, cy + 0.5 * hy), (cx, cy - 0.5 * hy)]
        R = hs + 0.5
        dbg = []
        for idx, kind in ((found_idx, "found"), (beam_idx, "beam")):
            best = None
            cmap = {}               # id phần tử -> cao đo được (để biết 550 lấy từ dầm nào)
            for q in near(idx, cx - R, cy - R, cx + R, cy + R):
                pr = [p_ for p_ in probes if in_xy(q, p_[0], p_[1])]
                if not pr:
                    continue
                sl = solids_of(q["e"])
                for (x, y) in pr:
                    for (a, b) in z_hits(sl, x, y, z_base - 8.0, z_base + 0.5):
                        if abs(b - z_base) <= TOL_BASE and (b - a) > 0.15:
                            th = eff_depth(b - a, q)
                            if kind == "beam" and th > MAX_BEAM:
                                continue
                            cmap[_id(q["e"])] = max(cmap.get(_id(q["e"]), 0.0), th)
                            if best is None or th > best:
                                best = th
            if best:
                dbg += [(kind, i_, round(t_), "tia") for i_, t_ in cmap.items()]
                return (kind, best), dbg
        if col_below(col, cx, cy, z_base):
            dbg.append("co cot ngay duoi chan cot -> dung tren cot, khong xet dam/mong")
            return None, dbg
        best = None
        for r in near(found_idx, cx - R, cy - R, cx + R, cy + R):
            inside = r["x0"] - 20 * MM <= cx <= r["x1"] + 20 * MM and r["y0"] - 20 * MM <= cy <= r["y1"] + 20 * MM
            th = mm(r["z1"] - r["z0"])
            dbg.append((_id(r["e"]), "mong", "mat tren %+dmm" % round(mm(r["z1"] - z_base)), "trong MB" if inside else "ngoai MB"))
            if inside and abs(r["z1"] - z_base) <= TOL_BASE and (r["z1"] - r["z0"]) > 0.15:
                if best is None or th > best:
                    best = th
        if best:
            return ("found", best), dbg
        for q in near(beam_idx, cx - R, cy - R, cx + R, cy + R):
            top_off, bot_off = mm(q["z1"] - z_base), mm(q["z0"] - z_base)
            if not (abs(top_off) <= 700 or bot_off <= 0 <= top_off):
                continue
            if not beam_flat(q):
                dbg.append((_id(q["e"]), "dam xien", "bo qua"))
                continue
            out, perp, h_al, h_pe = plan_rel(q, cx, cy, hx, hy)
            w = (beam_w(q) or 200.0) * MM
            ok_xy = perp <= w / 2.0 + 20 * MM and out <= h_al
            ok_z = abs(q["z1"] - z_base) <= TOL_BASE and (q["z1"] - q["z0"]) > 0.15
            dbg.append((_id(q["e"]), "dam", "mat tren %+dmm day %+dmm" % (round(top_off), round(bot_off)),
                        "lech ngang %dmm" % round(mm(perp)), "ngoai dau %dmm" % round(mm(out)),
                        "OK" if (ok_xy and ok_z) else ("lech cao do" if not ok_z else "ngoai mat bang")))
            if ok_xy and ok_z:
                hp = beam_h(q)
                th = hp if hp else eff_depth(q["z1"] - q["z0"], q)
                dbg.append(("beam", _id(q["e"]), round(th), "tham so h" if hp else "hop bao"))
                if th <= MAX_BEAM and (best is None or th > best):
                    best = th
        if best:
            return ("beam", best), dbg
        return None, dbg[:8]

    def top_plan_ok(q, cx, cy, hx, hy, z_top):
        """Dầm ngang có hộp bao cắt cao độ đỉnh cột (± TOL_TOP) và trục dầm đi vào vùng cột (không phụ thuộc phép cắt hình học)."""
        if not beam_flat(q):
            return False
        if not (q["z0"] <= z_top + TOL_TOP and q["z1"] >= z_top - TOL_TOP):
            return False
        out, perp, h_al, h_pe = plan_rel(q, cx, cy, hx, hy)
        w = (beam_w(q) or 200.0) * MM
        return out <= h_al + 40 * MM and perp <= h_pe + w / 2.0 - 20 * MM

    def beams_at_top(col, pt, z_top, hs):
        """Dầm ở ĐẦU cột. Phát hiện bằng (a) tia thẳng đứng tại tâm + 2 vòng điểm sát 4 mặt cột (40mm, 150mm),
        (b) dự phòng theo mặt bằng + cao độ hộp bao. Cao dầm = max(đo hình học, tham số h của loại dầm).
        R = cao dầm lớn nhất (mm); S = 'rộng x cao' của dầm vuông góc trục X cột."""
        cx, cy, hx, hy = col_extent(col, pt)
        probes = [(cx, cy)]
        for off in (40 * MM, 150 * MM):
            probes += [(cx + hx + off, cy), (cx - hx - off, cy), (cx, cy + hy + off), (cx, cy - hy - off)]
        try:
            bx = col.GetTransform().BasisX
            bxx, bxy = bx.X, bx.Y
        except Exception:
            bxx, bxy = 1.0, 0.0
        R = hs + 1.5
        deepest, perp, seen, rej = None, None, [], []
        for q in near(beam_idx, cx - R, cy - R, cx + R, cy + R):
            qid = _id(q["e"])
            pr = [p_ for p_ in probes if in_xy(q, p_[0], p_[1])]
            sl = solids_of(q["e"]) if pr else []
            best, why = None, "khong cat vung dau cot"
            for (x, y) in pr:
                for (a, b) in z_hits(sl, x, y, z_top - 6.0, z_top + 6.0):
                    if a <= z_top + TOL_TOP and b >= z_top - TOL_TOP:
                        if best is None or (b - a) > best:
                            best = b - a
                    else:
                        why = "lech cao do: day %+dmm, mat tren %+dmm so voi dinh cot" % (
                            round(mm(a - z_top)), round(mm(b - z_top)))
            try:
                by_plan = top_plan_ok(q, cx, cy, hx, hy, z_top)
            except Exception:
                by_plan = False
            if best is None and not by_plan:
                rej.append((qid, why))
                continue
            geo = eff_depth(best, q) if best is not None else None
            par = beam_h(q) if beam_flat(q) else None
            cands = [v for v in (geo, par) if v]
            if not cands and by_plan:
                cands = [mm(q["z1"] - q["z0"])]
            depth = max(cands) if cands else 0.0
            if depth <= 0:
                rej.append((qid, "khong do duoc cao dam"))
                continue
            if depth > MAX_BEAM:
                rej.append((qid, "cao %dmm > %dmm: khong phai dam ngang, bo qua" % (round(depth), MAX_BEAM)))
                continue
            if deepest is None or depth > deepest:
                deepest = depth
            is_perp = abs(q["d"][0] * bxx + q["d"][1] * bxy) < 0.35
            if is_perp:
                beam_w(q)
            kind_txt = "xien %.0f%%" % (q.get("slope", 0.0) * 100) if q.get("slope", 0.0) > 0.02 else "ngang"
            kind_txt += " geo=%s par=%s%s" % (round(geo) if geo else "-", round(par) if par else "-",
                                              " +mat_bang" if (best is None and by_plan) else "")
            seen.append((qid, round(depth), round(q["w"]) if q["w"] and q["w"] != -1 else None, is_perp, kind_txt))
            if is_perp and (perp is None or depth > perp[0]):
                perp = (depth, q["w"])
        S = "%dx%d" % (round(perp[1]), round(perp[0])) if perp and perp[1] and perp[1] != -1 else ""
        return deepest, S, seen, (perp is not None and not S), rej

    def cyl_diameter(el):
        """Đường kính (mm) từ mặt trụ đứng lớn nhất của khối hình học; None nếu không thấy."""
        best = None
        for sd in solids_of(el):
            try:
                for f in sd.Faces:
                    if f.GetType().Name != "CylindricalFace":
                        continue
                    if abs(f.Axis.Z) < 0.99:
                        continue
                    dmm = 2.0 * mm(f.Radius)
                    if dmm >= 100.0 and (best is None or dmm > best):
                        best = dmm
            except Exception:
                continue
        return best

    import re
    cyl_cache, diag_types, round_marks, square_marks = {}, set(), {}, set()
    items, warns = [], []
    nobeam = []
    nomark = {}             # Mark tạm (Family : Type) -> danh sách Id cột chưa có Mark
    slanted_ids = []
    nosup_logged = [0]
    ncol = len(cols)
    for n_i, col in enumerate(cols):
        if n_i % 100 == 0:
            log("quet: cot %d/%d" % (n_i, ncol))
            if set_status:
                set_status("Đang quét cột %d/%d ..." % (n_i, ncol))
            if refresh:
                try:
                    refresh()
                except Exception:
                    pass
        try:
            slanted = bool(getattr(col, "IsSlantedColumn", False))
            sym = doc.GetElement(col.GetTypeId())
            pm = col.get_Parameter(BIP.ALL_MODEL_MARK)
            mark = (pm.AsString() or "").strip() if pm is not None else ""
            if not mark:
                mark = "%s : %s" % (sym.FamilyName, sym.Name)
                nomark.setdefault(mark, []).append(_id(col))
            lb, zb_int, zb = level_of(col, BIP.FAMILY_BASE_LEVEL_PARAM, BIP.FAMILY_BASE_LEVEL_OFFSET_PARAM)
            lt, zt_int, zt = level_of(col, BIP.FAMILY_TOP_LEVEL_PARAM, BIP.FAMILY_TOP_LEVEL_OFFSET_PARAM)
            if lb is None or lt is None:
                warns.append("Cột %s (Id %s) thiếu level đáy/đỉnh, bỏ qua" % (mark, _id(col)))
                continue
            pt = col.Location.Point if isinstance(col.Location, DB.LocationPoint) else None
            R, S, sup = None, "", None
            cid = _id(col)
            slant_deg, axis_len = 0.0, None
            if slanted:
                # ---- CỘT XIÊN: lấy 2 đầu trục. Cao độ lấy theo đầu trục (đã quy về toạ độ dự án), H = chiều dài TRỤC.
                loc = col.Location
                if not isinstance(loc, DB.LocationCurve):
                    warns.append("Cột xiên %s (Id %s) không có đường trục đọc được, bỏ qua" % (mark, cid))
                    continue
                crv = loc.Curve
                p0, p1 = crv.GetEndPoint(0), crv.GetEndPoint(1)
                if p0.Z > p1.Z:
                    p0, p1 = p1, p0
                dz = p1.Z - p0.Z
                run = ((p1.X - p0.X) ** 2 + (p1.Y - p0.Y) ** 2) ** 0.5
                if dz < 1e-6:
                    warns.append("Cột xiên %s (Id %s) nằm ngang, bỏ qua" % (mark, cid))
                    continue
                slant_deg = math.degrees(math.atan2(run, dz))
                axis_len = mm(crv.Length)
                try:
                    shift = lb.ProjectElevation - lb.Elevation
                except Exception:
                    shift = 0.0
                zb_int, zt_int = p0.Z, p1.Z
                zb, zt = p0.Z + shift, p1.Z + shift
                pt = p0
                slanted_ids.append(cid)
                log("cot XIEN Id %s mark=%s goc=%.1f do, truc=%.0f mm, cao dung=%.0f mm" % (cid, mark, slant_deg, axis_len, mm(dz)))
            bval, hval = dim_param([col, sym], NB), dim_param([col, sym], NH)
            shape = "rect"
            # ---- nhận diện cột TRÒN (không dựa riêng vào tham số vì family tròn thường vẫn đặt tên b / h) ----
            miss_ = (not bval) or (not hval)
            ambig = miss_ or abs((bval or 0.0) - (hval or 0.0)) < 1.0      # thiếu b/h hoặc b = h: có thể là tròn
            why = ""
            dval = None
            if not bval and not hval:
                dval = dim_param([col, sym], pn("names_dia", ["Diameter", "D", "Đường kính", "Đường kính cột", "DK", "d"]))
                why = "tham số đường kính" if dval else ""
            if not why and ambig:
                nm_txt = ("%s %s" % (sym.FamilyName, sym.Name)).lower()
                if re.search(r"tròn|round|circ|(^|[^a-z])tron([^a-z]|$)", nm_txt):
                    why = "tên family/type có chữ 'tròn / round'"
            if not why and ambig:
                gk = (_id(sym), round(bval or 0.0), round(hval or 0.0))
                if gk not in cyl_cache:
                    cyl_cache[gk] = cyl_diameter(col)
                if cyl_cache[gk]:
                    dval, why = cyl_cache[gk], "mặt trụ đứng trong hình học"
            if why:
                if not dval:
                    dval = cyl_cache.get((_id(sym), round(bval or 0.0), round(hval or 0.0))) or cyl_diameter(col) \
                        or bval or hval
                if dval:
                    bval = hval = dval
                    shape = "round"
                    round_marks.setdefault(mark, (round(dval), why))
                    log("cot TRON Id %s mark=%s D=%s (nhan theo: %s)" % (cid, mark, round(dval), why))
            if shape == "rect" and ambig:
                tkey = _id(sym)
                if tkey not in diag_types:                 # ghi 1 lần / loại để biết family đặt tên tham số thế nào
                    diag_types.add(tkey)
                    try:
                        pnames = [p_.Definition.Name for p_ in sym.Parameters
                                  if p_.StorageType == DB.StorageType.Double][:30]
                    except Exception:
                        pnames = []
                    log("cot KHONG nhan la tron (b=%s h=%s) family='%s' type='%s' tham so so: %s" % (
                        bval, hval, sym.FamilyName, sym.Name, pnames))
                    if bval and hval:
                        square_marks.add(mark)
            hs = max(bval or 0.0, hval or 0.0, 300.0) / 2.0 * MM
            if pt is not None and not slanted:
                R, S, seen, nowidth, rej = beams_at_top(col, pt, zt_int, hs)
                sup, sdbg = support_under(col, pt, zb_int, hs)
                if not sup and nosup_logged[0] < 30:         # luôn ghi lý do không dò được móng / dầm (tối đa 30 dòng / lần quét)
                    nosup_logged[0] += 1
                    log("KHONG do duoc mong/dam do: cot Id %s mark=%s cao do chan=%.0f mm, dung sai=%s mm | chan doan: %s" % (
                        cid, mark, mm(zb_int), st.get("tol_base", 120), sdbg[:4]))
                dlog("cot Id %s mark=%s b=%s h=%s | R=%s S=%s | do=%s | DO_DBG=%s | dam_o_dinh=%s | DAM_BI_LOAI=%s" % (
                    cid, mark, bval, hval, R, S or "-", sup, sdbg, seen, rej[:6]))
                if nowidth:
                    warns.append("Cột %s (Id %s): có dầm giao nhưng không đọc được bề rộng dầm (tên tham số lạ) -> nhập tay cột 'Dầm giao'" % (mark, cid))
                if not seen:
                    nobeam.append(mark)
            items.append(dict(
                mark=mark, x=(mm(pt.X) if pt is not None else None), y=(mm(pt.Y) if pt is not None else None),
                base_name=lb.Name, top_name=lt.Name, base_z=mm(zb), top_z=mm(zt),
                b=bval, h=hval, R=R, S=S, support=sup, id=cid, shape=shape,
                slant=(slant_deg if slant_deg >= 0.5 else 0.0), axis_len=axis_len))
        except Exception as ex:
            warns.append("Lỗi đọc cột Id %s: %s" % (_id(col), ex))
    if nomark:
        n_ = sum(len(v) for v in nomark.values())
        warns.append("%d cột chưa có Mark, tạm gom theo 'Family : Type' (%s). Nên đặt Mark cho từng cột trong Revit "
                     "(hoặc đổi tên Mark sau khi quét) để các cột khác tầng / khác vị trí không bị gộp nhầm." % (
                         n_, "; ".join("%s: %d cột" % (m_, len(v_)) for m_, v_ in sorted(nomark.items())[:8])))
    if slanted_ids:
        log("quet: %d cot xien" % len(slanted_ids))
    if nobeam:
        warns.append("Không thấy dầm nào ở đỉnh cột: %s (nếu thực tế có dầm, kiểm tra dầm có phải loại Structural Framing/Beam và cao độ đỉnh dầm = đỉnh cột)" % ", ".join(sorted(set(nobeam))[:15]))
    if round_marks:
        warns.append("Đã nhận %d Mark cột TRÒN: %s. Nếu nhận sai: gõ 'Chữ nhật' vào cột Dạng." % (
            len(round_marks), ", ".join("%s Ø%d (%s)" % (m_, d_, w_) for m_, (d_, w_) in sorted(round_marks.items())[:12])))
    sq_ = sorted(square_marks - set(round_marks))
    if sq_:
        warns.append("Cột có b = h nhưng KHÔNG thấy dấu hiệu tròn: %s. Nếu thực tế là cột TRÒN: gõ 'Tròn' vào cột Dạng "
                     "(áp cho cả Mark) và gửi file cottools.log để cải thiện nhận diện." % ", ".join(sq_[:15]))
    log("quet: xong %d cot hop le" % len(items))
    return items, warns, src
