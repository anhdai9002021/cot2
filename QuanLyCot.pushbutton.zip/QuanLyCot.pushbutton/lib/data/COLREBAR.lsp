;;; ===========================================================================
;;; COLREBAR.lsp  -  Thong ke thep cot trong ban ve AutoCAD
;;;
;;; Doc du lieu an (XDATA, ung dung "COLREBAR") do excel_to_dxf.py gan vao
;;; thanh thep va dai, roi tinh khoi luong theo tung doan cot.
;;;
;;; LENH
;;;   TKTHEP      Thong ke, in ket qua ra dong lenh, ghi file CSV
;;;   TKTHEPBANG  Thong ke va ve bang (LINE + TEXT) vao ban ve
;;;   VECOT       Chen ban ve cot (file DXF tu excel_to_dxf.py) vao ban ve dang mo
;;;
;;; CACH NAP:  APPLOAD -> chon COLREBAR.lsp   (hoac go (load "duong/dan/COLREBAR.lsp"))
;;;
;;; TUONG THICH: chi dung ham AutoLISP co ban (khong dung vl-*, vla-*, vlax-*),
;;; nen chay tren AutoCAD day du tu doi cu den 2025 va AutoCAD LT co ho tro AutoLISP.
;;; File chi chua ky tu ASCII de khong loi ma hoa tren moi phien ban.
;;;
;;; QUY UOC TINH (khop voi thong_ke_thep.py):
;;;   - Khoi luong 1 m thep = 0.00617 * d^2  (kg/m, d tinh bang mm)
;;;   - Chieu dai thanh doc = chieu dai hinh hoc cua polyline thep tren ban ve
;;;   - Thep noi = N x LAP cua cac thanh co noi;  Thep doc = tong thanh doc - thep noi
;;;   - Thep dai = so luong dai x chieu dai 1 dai (lay tu du lieu an)
;;;   - Moi khoi luong nhan voi SL (so luong cot giong nhau)
;;; ===========================================================================

(setq *CR-APP* "COLREBAR")
(setq *CR-WT* 0.00617)       ; kg/m = *CR-WT* * d * d
(setq *CR-SL* nil)           ; (("C1" . 2.0) ("C2" . 9.0) ...)
(setq *CR-ROWS* nil)         ; ((key mark seg doc dai noi) ...)
(setq *CR-DIA* nil)          ; ((d chieu-dai-m kg) ...)
(setq *CR-SEG* nil)          ; (("C3|1" tang-dau tang-cuoi dong-excel) ...)

;;; ---------------------------------------------------------------------------
;;; Ham chuoi
;;; ---------------------------------------------------------------------------
(defun cr:pos (c s / i n r)
  ;; vi tri (tinh tu 1) cua ky tu c dau tien trong s, nil neu khong co
  (setq i 1 n (strlen s) r nil)
  (while (and (null r) (<= i n))
    (if (= (substr s i 1) c) (setq r i))
    (setq i (1+ i)))
  r)

(defun cr:split (s sep / out cur i n c)
  (setq out nil cur "" i 1 n (strlen s))
  (while (<= i n)
    (setq c (substr s i 1))
    (if (= c sep)
      (setq out (cons cur out) cur "")
      (setq cur (strcat cur c)))
    (setq i (1+ i)))
  (reverse (cons cur out)))

(defun cr:kv (parts / out p pos)
  ;; ("M=C3" "SH=1") -> (("M" . "C3") ("SH" . "1"))
  (setq out nil)
  (foreach p parts
    (setq pos (cr:pos "=" p))
    (if pos
      (setq out (cons (cons (substr p 1 (1- pos)) (substr p (1+ pos))) out))))
  out)

(defun cr:get (key al / p)
  (setq p (assoc key al))
  (if p (cdr p) nil))

(defun cr:num (s)
  (if s (atof s) 0.0))

(defun cr:pad (s n)
  (while (< (strlen s) n) (setq s (strcat s " ")))
  s)

(defun cr:lpad (s n)
  (while (< (strlen s) n) (setq s (strcat " " s)))
  s)

(defun cr:fmt (v dec / s p)
  ;; so thuc -> chuoi 2 chu so le; dec = "." hoac ","
  (setq s (rtos v 2 2))
  (if (= dec ",")
    (progn
      (setq p (cr:pos "." s))
      (if p (setq s (strcat (substr s 1 (1- p)) "," (substr s (1+ p)))))))
  s)

;;; ---------------------------------------------------------------------------
;;; Sap xep (chen dan, khong dung vl-sort de chay moi phien ban)
;;; ---------------------------------------------------------------------------
(defun cr:ins (x lst lessfn)
  (cond
    ((null lst) (list x))
    ((apply lessfn (list x (car lst))) (cons x lst))
    (t (cons (car lst) (cr:ins x (cdr lst) lessfn)))))

(defun cr:sort (lst lessfn / out x)
  (setq out nil)
  (foreach x lst (setq out (cr:ins x out lessfn)))
  out)

(defun cr:strless (a b)
  ;; "C2" < "C10": so sanh do dai truoc, roi so sanh chuoi
  (or (< (strlen a) (strlen b))
      (and (= (strlen a) (strlen b)) (< a b))))

(defun cr:rowless (a b)
  (if (= (cadr a) (cadr b))
    (< (caddr a) (caddr b))
    (cr:strless (cadr a) (cadr b))))

(defun cr:dialess (a b)
  (< (car a) (car b)))

;;; ---------------------------------------------------------------------------
;;; Doc du lieu an va hinh hoc
;;; ---------------------------------------------------------------------------
(defun cr:xstrings (en / ed app out x)
  ;; tra ve danh sach chuoi XDATA (ma 1000) cua ung dung COLREBAR
  (setq ed (entget en (list *CR-APP*))
        app (assoc -3 ed)
        out nil)
  (if app
    (foreach x (cdr (assoc *CR-APP* (cdr app)))
      (if (= (car x) 1000) (setq out (cons (cdr x) out)))))
  (reverse out))

(defun cr:seglen (p1 p2 b / c th)
  ;; chieu dai doan thang hoac cung (bulge b) giua p1 va p2
  (setq c (distance p1 p2))
  (if (and b (> (abs b) 0.000000001) (> c 0.0))
    (progn
      (setq th (* 4.0 (atan (abs b))))
      (* (/ c (* 2.0 (sin (/ th 2.0)))) th))
    c))

(defun cr:polylen (en / ed pts p tot)
  ;; chieu dai LWPOLYLINE (co tinh cung); pts = ((diem bulge) ...)
  (setq ed (entget en) pts nil tot 0.0)
  (foreach p ed
    (cond
      ((= (car p) 10)
       (setq pts (cons (list (cdr p) 0.0) pts)))
      ((and (= (car p) 42) pts)
       (setq pts (cons (list (car (car pts)) (cdr p)) (cdr pts))))))
  (setq pts (reverse pts))
  (while (cdr pts)
    (setq tot (+ tot (cr:seglen (car (car pts)) (car (cadr pts)) (cadr (car pts)))))
    (setq pts (cdr pts)))
  tot)

;;; ---------------------------------------------------------------------------
;;; Quet va tinh khoi luong
;;; ---------------------------------------------------------------------------
(defun cr:sl (m / e)
  (setq e (assoc m *CR-SL*))
  (if e (cdr e) 1.0))

(defun cr:readsegs (m lst / s p)
  ;; doc cac dong SEG trong XDATA cua tieu de cot: ten tang va dong Excel
  (foreach s lst
    (setq p (cr:split s "|"))
    (if (and (= (car p) "SEG") (> (length p) 13))
      (setq *CR-SEG* (cons (list (strcat m "|" (nth 1 p)) (nth 2 p) (nth 3 p) (nth 13 p)) *CR-SEG*)))))

(defun cr:seginfo (key idx / e)
  ;; idx: 1 = tang dau, 2 = tang cuoi, 3 = dong Excel
  (setq e (assoc key *CR-SEG*))
  (if e (nth idx e) ""))

(defun cr:scan (ss / i en xs parts kind al bars stirs)
  ;; tra ve (danh-sach-thanh danh-sach-dai); ghi SL vao *CR-SL*
  (setq *CR-SL* nil *CR-SEG* nil bars nil stirs nil i 0)
  (repeat (sslength ss)
    (setq en (ssname ss i)
          i (1+ i)
          xs (cr:xstrings en))
    (if xs
      (progn
        (setq parts (cr:split (car xs) "|")
              kind (car parts)
              al (cr:kv (cdr parts)))
        (cond
          ((= kind "COL")
           (setq *CR-SL* (cons (cons (cr:get "M" al) (cr:num (cr:get "SL" al))) *CR-SL*))
           (cr:readsegs (cr:get "M" al) (cdr xs)))
          ((= kind "BAR")
           (setq bars (cons (list al (cr:polylen en)) bars)))
          ((= kind "STIR")
           (setq stirs (cons al stirs)))))))
  (list bars stirs))

(defun cr:addrow (m seg doc dai noi / key e)
  (setq key (strcat m "|" (itoa seg)))
  (setq e (assoc key *CR-ROWS*))
  (if e
    (setq *CR-ROWS*
           (subst (list key m seg (+ (nth 3 e) doc) (+ (nth 4 e) dai) (+ (nth 5 e) noi))
                  e *CR-ROWS*))
    (setq *CR-ROWS* (cons (list key m seg doc dai noi) *CR-ROWS*))))

(defun cr:adddia (d len kg / e)
  (setq e (assoc d *CR-DIA*))
  (if e
    (setq *CR-DIA* (subst (list d (+ (cadr e) len) (+ (caddr e) kg)) e *CR-DIA*))
    (setq *CR-DIA* (cons (list d len kg) *CR-DIA*))))

(defun cr:compute (res / b s al m sl d n len lap w tot noi seg num ls)
  (setq *CR-ROWS* nil *CR-DIA* nil)
  ;; thanh doc
  (foreach b (car res)
    (setq al (car b)
          len (cadr b)
          m (cr:get "M" al)
          sl (cr:sl m)
          d (atoi (cr:get "D" al))
          n (atoi (cr:get "N" al))
          seg (atoi (cr:get "SEG" al))
          lap (cr:num (cr:get "LAP" al))
          w (* *CR-WT* d d)
          tot (* n (/ len 1000.0) w sl)
          noi (* n (/ lap 1000.0) w sl))
    (cr:addrow m seg (- tot noi) 0.0 noi)
    (cr:adddia d (* n (/ len 1000.0) sl) tot))
  ;; dai
  (foreach s (cadr res)
    (setq m (cr:get "M" s)
          sl (cr:sl m)
          d (atoi (cr:get "D" s))
          seg (atoi (cr:get "SEG" s))
          num (atoi (cr:get "NUM" s))
          ls (cr:num (cr:get "L" s))
          w (* *CR-WT* d d)
          tot (* num (/ ls 1000.0) w sl))
    (cr:addrow m seg 0.0 tot 0.0)
    (cr:adddia d (* num (/ ls 1000.0) sl) tot))
  (princ))

;;; ---------------------------------------------------------------------------
;;; Chon doi tuong
;;; ---------------------------------------------------------------------------
(defun cr:select ( / ss)
  (prompt "\nChon cac cot can thong ke <Enter = toan bo ban ve>: ")
  (setq ss (ssget '((-3 ("COLREBAR")))))
  (if (null ss)
    (setq ss (ssget "_X" '((-3 ("COLREBAR"))))))
  ss)

;;; ---------------------------------------------------------------------------
;;; In ket qua ra dong lenh
;;; ---------------------------------------------------------------------------
(defun cr:report ( / rows r t1 t2 t3 d)
  (setq rows (cr:sort *CR-ROWS* 'cr:rowless)
        t1 0.0 t2 0.0 t3 0.0)
  (princ (strcat "\n\n" (cr:pad "Pier" 8) (cr:pad "Dong" 6) (cr:pad "Tang dau" 10) (cr:pad "Tang cuoi" 10)
                 (cr:lpad "Thep doc Kg" 13) (cr:lpad "Thep dai Kg" 13) (cr:lpad "Thep noi Kg" 13)))
  (foreach r rows
    (princ (strcat "\n" (cr:pad (nth 1 r) 8) (cr:pad (cr:seginfo (car r) 3) 6)
                   (cr:pad (cr:seginfo (car r) 1) 10) (cr:pad (cr:seginfo (car r) 2) 10)
                   (cr:lpad (cr:fmt (nth 3 r) ".") 13)
                   (cr:lpad (cr:fmt (nth 4 r) ".") 13)
                   (cr:lpad (cr:fmt (nth 5 r) ".") 13)))
    (setq t1 (+ t1 (nth 3 r)) t2 (+ t2 (nth 4 r)) t3 (+ t3 (nth 5 r))))
  (princ (strcat "\n" (cr:pad "TONG" 34)
                 (cr:lpad (cr:fmt t1 ".") 13) (cr:lpad (cr:fmt t2 ".") 13) (cr:lpad (cr:fmt t3 ".") 13)))
  (princ "\n\nTheo duong kinh (da nhan SL):")
  (princ (strcat "\n" (cr:pad "D (mm)" 10) (cr:lpad "Dai (m)" 12) (cr:lpad "Kg" 12)))
  (foreach d (cr:sort *CR-DIA* 'cr:dialess)
    (princ (strcat "\n" (cr:pad (itoa (car d)) 10)
                   (cr:lpad (cr:fmt (cadr d) ".") 12)
                   (cr:lpad (cr:fmt (caddr d) ".") 12))))
  (princ "\n(Kg. Thep noi = phan chong LAP; thep doc = tong thanh doc - thep noi. Khop cot AB, AC, AD cua sheet Column Detail)")
  (princ))

;;; ---------------------------------------------------------------------------
;;; Ghi CSV
;;; ---------------------------------------------------------------------------
(defun cr:writecsv (path dec / f sep rows r)
  (setq sep (if (= dec ",") ";" ","))
  (setq f (open path "w"))
  (if f
    (progn
      (setq rows (cr:sort *CR-ROWS* 'cr:rowless))
      (write-line (strcat "Pier" sep "DongExcel" sep "TangDau" sep "TangCuoi" sep "ThepDoc_Kg" sep "ThepDai_Kg" sep "ThepNoi_Kg") f)
      (foreach r rows
        (write-line
          (strcat (nth 1 r) sep (cr:seginfo (car r) 3) sep
                  (cr:seginfo (car r) 1) sep (cr:seginfo (car r) 2) sep
                  (cr:fmt (nth 3 r) dec) sep (cr:fmt (nth 4 r) dec) sep
                  (cr:fmt (nth 5 r) dec))
          f))
      (close f)
      T)
    nil))

(defun cr:askdec ( / r)
  (initget "Cham Phay")
  (setq r (getkword "\nDau thap phan trong file CSV [Cham/Phay] <Cham>: "))
  (if (= r "Phay") "," "."))

(defun cr:savecsv ( / dec path)
  (setq path (getfiled "Luu file thong ke CSV" (strcat (getvar "DWGPREFIX") "thongke_thep") "csv" 1))
  (if path
    (progn
      (setq dec (cr:askdec))
      (if (cr:writecsv path dec)
        (princ (strcat "\nDa ghi: " path))
        (princ "\nKhong ghi duoc file (kiem tra quyen ghi hoac file dang mo trong Excel)."))))
  (princ))

;;; ---------------------------------------------------------------------------
;;; Ve bang vao ban ve (LINE + TEXT, khong can ActiveX)
;;; ---------------------------------------------------------------------------
(defun cr:mkline (p1 p2)
  (entmake (list '(0 . "LINE") (cons 10 p1) (cons 11 p2))))

(defun cr:mktext (p h s)
  (entmake (list '(0 . "TEXT") (cons 10 p) (cons 40 h) (cons 1 s))))

(defun cr:table (pt h widths rows / x0 y0 rh nr xs x i c r s y w)
  ;; ve bang: pt = goc tren-trai, h = cao chu, widths = be rong cot (don vi h)
  ;; rows = danh sach dong, moi dong la danh sach chuoi. Tra ve y day bang.
  (setq x0 (car pt) y0 (cadr pt) rh (* 2.0 h) nr (length rows))
  (setq xs (list x0) x x0)
  (foreach w widths
    (setq x (+ x (* w h)))
    (setq xs (append xs (list x))))
  (setq i 0)
  (repeat (1+ nr)
    (setq y (- y0 (* i rh)))
    (cr:mkline (list x0 y 0.0) (list (last xs) y 0.0))
    (setq i (1+ i)))
  (foreach x xs
    (cr:mkline (list x y0 0.0) (list x (- y0 (* nr rh)) 0.0)))
  (setq i 0)
  (foreach r rows
    (setq c 0)
    (foreach s r
      (if (/= s "")
        (cr:mktext (list (+ (nth c xs) (* 0.4 h))
                         (+ (- y0 (* (1+ i) rh)) (* 0.5 h))
                         0.0)
                   h s))
      (setq c (1+ c)))
    (setq i (1+ i)))
  (- y0 (* nr rh)))

(defun cr:drawtables (pt h / rows data r t1 t2 t3 yb d)
  (setq rows (cr:sort *CR-ROWS* 'cr:rowless)
        data (list (list "Pier" "Dong" "Tang dau" "Tang cuoi" "Thep doc (Kg)" "Thep dai (Kg)" "Thep noi (Kg)"))
        t1 0.0 t2 0.0 t3 0.0)
  (foreach r rows
    (setq data
           (append data
                   (list (list (nth 1 r) (cr:seginfo (car r) 3) (cr:seginfo (car r) 1) (cr:seginfo (car r) 2)
                               (cr:fmt (nth 3 r) ".") (cr:fmt (nth 4 r) ".") (cr:fmt (nth 5 r) ".")))))
    (setq t1 (+ t1 (nth 3 r)) t2 (+ t2 (nth 4 r)) t3 (+ t3 (nth 5 r))))
  (setq data (append data
                     (list (list "TONG" "" "" ""
                                 (cr:fmt t1 ".") (cr:fmt t2 ".") (cr:fmt t3 ".")))))
  (cr:mktext (list (car pt) (+ (cadr pt) (* 0.6 h)) 0.0) (* 1.4 h) "BOC TACH KHOI LUONG THEP COT (Kg)")
  (setq yb (cr:table pt h '(7 6 9 9 14 14 14) data))
  ;; bang theo duong kinh
  (setq data (list (list "D (mm)" "Dai (m)" "Khoi luong (kg)")))
  (foreach d (cr:sort *CR-DIA* 'cr:dialess)
    (setq data (append data (list (list (itoa (car d)) (cr:fmt (cadr d) ".") (cr:fmt (caddr d) "."))))))
  (cr:table (list (car pt) (- yb (* 3.0 h)) 0.0) h '(10 16 20) data)
  (princ))

;;; ---------------------------------------------------------------------------
;;; Lenh
;;; ---------------------------------------------------------------------------
(defun c:TKTHEP ( / ss res)
  (regapp *CR-APP*)
  (setq ss (cr:select))
  (if (null ss)
    (prompt "\nKhong thay du lieu COLREBAR trong ban ve (can ban ve do excel_to_dxf.py tao).")
    (progn
      (setq res (cr:scan ss))
      (cr:compute res)
      (if (null *CR-ROWS*)
        (prompt "\nKhong co thanh thep hoac dai nao co du lieu COLREBAR.")
        (progn
          (cr:report)
          (cr:savecsv)))))
  (princ))

(defun c:TKTHEPBANG ( / ss res pt h)
  (regapp *CR-APP*)
  (setq ss (cr:select))
  (if (null ss)
    (prompt "\nKhong thay du lieu COLREBAR trong ban ve (can ban ve do excel_to_dxf.py tao).")
    (progn
      (setq res (cr:scan ss))
      (cr:compute res)
      (if (null *CR-ROWS*)
        (prompt "\nKhong co thanh thep hoac dai nao co du lieu COLREBAR.")
        (progn
          (cr:report)
          (setq pt (getpoint "\nDiem chen bang (goc tren-trai): "))
          (if pt
            (progn
              (setq h (getreal "\nChieu cao chu <125>: "))
              (if (null h) (setq h 125.0))
              (cr:drawtables pt h)
              (princ "\nDa ve bang."))))))) 
  (princ))

;;; ---------------------------------------------------------------------------
;;; Chen ban ve cot (file DXF/DWG do excel_to_dxf.py tao) vao ban ve dang mo
;;;   VECOT   : chon file roi chon diem chen
;;; Nut "Gui sang AutoCAD" trong tool goi san cr:insfile qua COM (dua_vao_cad.ps1)
;;; ---------------------------------------------------------------------------
(setq *CR-OLDERR* nil *CR-OS* nil *CR-CE* nil *CR-IU* nil)

(defun cr:err (msg)
  ;; khoi phuc OSMODE / CMDECHO neu dang chen bi loi hoac bi huy
  (if *CR-OS* (setvar "OSMODE" *CR-OS*))
  (if *CR-CE* (setvar "CMDECHO" *CR-CE*))
  (if *CR-IU* (setvar "INSUNITS" *CR-IU*))
  (setq *error* *CR-OLDERR*)
  (if (and msg (not (wcmatch (strcase msg) "*BREAK*,*CANCEL*,*EXIT*")))
    (princ (strcat "\nLoi: " msg)))
  (princ))

(defun cr:insfile (path / pt)
  (if (null (findfile path))
    (prompt (strcat "\nKhong tim thay file: " path))
    (progn
      (setq pt (getpoint "\nChon diem chen ban ve cot (goc duoi-trai): "))
      (if pt
        (progn
          (setq *CR-OLDERR* *error*
                *CR-OS* (getvar "OSMODE")
                *CR-CE* (getvar "CMDECHO")
                *CR-IU* (getvar "INSUNITS")
                *error* cr:err)
          (setvar "OSMODE" 0)
          (setvar "CMDECHO" 0)
          ;; INSUNITS = 0 (khong don vi) -> AutoCAD khong co/gian ban ve khi chen
          (setvar "INSUNITS" 0)
          ;; dau * truoc ten file = chen xong tu explode thanh cac doi tuong roi
          (command "_.-INSERT" (strcat "*" path) pt 1.0 0.0)
          (setvar "OSMODE" *CR-OS*)
          (setvar "CMDECHO" *CR-CE*)
          (setvar "INSUNITS" *CR-IU*)
          (setq *error* *CR-OLDERR*)
          (command "_.ZOOM" "_E")
          (princ "\nDa chen ban ve cot. Go TKTHEP de thong ke thep.")))))
  (princ))

(defun c:VECOT ( / path)
  (setq path (getfiled "Chon file ban ve cot (DXF/DWG)" "" "dxf;dwg" 0))
  (if path (cr:insfile path))
  (princ))

(princ "\nCOLREBAR da nap. Lenh: VECOT (chen ban ve cot), TKTHEP (thong ke + CSV), TKTHEPBANG (ve bang).")
(princ)
