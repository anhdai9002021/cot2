param(
  [Parameter(Mandatory=$true)][string]$Lsp,
  [Parameter(Mandatory=$true)][string]$Dxf
)
# Nap COLREBAR.lsp vao AutoCAD dang mo va chen ban ve cot (COM, khong can pywin32)

if (-not (Test-Path -LiteralPath $Lsp)) { Write-Host "[LOI] Khong thay file Lisp: $Lsp"; exit 2 }
if (-not (Test-Path -LiteralPath $Dxf)) { Write-Host "[LOI] Khong thay file ban ve: $Dxf"; exit 2 }

# Tim AutoCAD dang chay (thu ProgID chung, roi tung phien ban 2026 -> 2015)
$progIds = @('AutoCAD.Application')
foreach ($v in @('26','25','24.3','24.2','24.1','24','23.1','23','22','21','20.1','20')) {
  $progIds += "AutoCAD.Application.$v"
}
$acad = $null
foreach ($id in $progIds) {
  try {
    $acad = [System.Runtime.InteropServices.Marshal]::GetActiveObject($id)
    if ($acad -ne $null) { Write-Host "Da ket noi AutoCAD ($id)"; break }
  } catch { $acad = $null }
}
if ($acad -eq $null) {
  Write-Host "[LOI] Khong tim thay AutoCAD dang mo."
  Write-Host "      Hay mo AutoCAD (va mo mot ban ve), roi chay lai. Neu AutoCAD dang chay bang quyen Administrator thi bat cung phai chay bang quyen do."
  exit 3
}

$doc = $null
try { $doc = $acad.ActiveDocument } catch { $doc = $null }
if ($doc -eq $null) {
  Write-Host "[LOI] AutoCAD chua co ban ve nao dang mo. Hay mo hoac tao mot ban ve roi chay lai."
  exit 4
}

$lspPath = (Resolve-Path -LiteralPath $Lsp).Path -replace '\\','/'
$dxfPath = (Resolve-Path -LiteralPath $Dxf).Path -replace '\\','/'

function Send-Cad($text, $label, $fatal) {
  try {
    $doc.SendCommand($text)
  } catch {
    Write-Host "[LOI] Buoc '$label': $($_.Exception.Message)"
    if ($fatal) {
      Write-Host "      Thu: nhan ESC trong AutoCAD, dong hop thoai neu co, roi chay lai."
      Write-Host "      Hoac lam tay: trong AutoCAD go APPLOAD nap COLREBAR.lsp, roi go VECOT va chon COT.dxf."
      exit 5
    }
  }
}

# huy lenh dang do (Ctrl+C); neu AutoCAD tu choi thi bo qua, khong sao
Send-Cad (([string][char]3) + ([string][char]3)) "huy lenh dang do" $false
# nap Lisp
Send-Cad ('(load "' + $lspPath + '")' + "`n") "nap Lisp" $true
# nap lenh COTSUA / COTTK (doi D thep theo so hieu ngay trong AutoCAD) + ghi nho thu muc CotTools cho lenh do
$dataDir = Split-Path -Parent $lspPath
$libDir = Split-Path -Parent $dataDir
$sua = $dataDir + '/COLSUA.lsp'
if (Test-Path -LiteralPath $sua) {
  Send-Cad ('(setenv "COTTOOLS_HOME" "' + $libDir + '")' + "`n") "ghi thu muc CotTools" $false
  Send-Cad ('(load "' + $sua + '")' + "`n") "nap COLSUA.lsp" $false
}
# chen ban ve
Send-Cad ('(cr:insfile "' + $dxfPath + '")' + "`n") "chen ban ve" $true

Write-Host ""
Write-Host "Da gui lenh sang AutoCAD."
Write-Host "-> Quay lai cua so AutoCAD:"
Write-Host "   1) Neu AutoCAD hoi nap Lisp (bao mat) -> chon 'Load Once' hoac 'Always Load'."
Write-Host "   2) CLICK diem chen ban ve."
Write-Host "   3) Sau khi chen: go COTSUA de doi D thep theo so hieu (mat dung + mat cat + bang tu cap nhat)."
exit 0
