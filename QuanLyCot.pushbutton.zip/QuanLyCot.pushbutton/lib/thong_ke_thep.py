# -*- coding: utf-8 -*-
"""
Thống kê thép cột từ bản vẽ DXF do excel_to_dxf.py sinh ra (đọc dữ liệu ẩn COLREBAR).

    python thong_ke_thep.py COT_C1-C4.dxf
    python thong_ke_thep.py COT_C1-C4.dxf --csv ketqua.csv --xlsx ketqua.xlsx

Kết quả theo từng đoạn cột (mỗi dòng = 1 dòng trong sheet Column Detail) để dán vào
cột AB (Thép dọc), AC (Thép đai), AD (Thép nối), đơn vị kg.

Quy ước tính (đổi ở đầu file nếu cần):
- Trọng lượng 1 m thép = 0.00617 x d^2 (kg/m, d tính bằng mm)
- Chiều dài thanh dọc = chiều dài hình học của polyline thép trên bản vẽ (đã gồm móc, đoạn gãy)
- Thép nối  = phần chồng LAP của các thanh có nối (N x LAP)
- Thép dọc  = tổng chiều dài các thanh - thép nối      (dọc + nối = tổng thép dọc đã vẽ)
- Thép đai  = số lượng đai x chiều dài 1 đai
- Mọi khối lượng nhân với SL (số lượng cột giống nhau, cột AA)
"""
import argparse
import math
import sys

WT_K = 0.00617          # kg/m = WT_K * d^2
APP = "COLREBAR"


def read_pairs(path):
    with open(path, "r", encoding="utf-8", errors="replace", newline="") as f:
        lines = f.read().replace("\r\n", "\n").replace("\r", "\n").split("\n")
    if lines and lines[-1] == "":
        lines.pop()
    return [(int(lines[i].strip()), lines[i + 1]) for i in range(0, len(lines) - 1, 2)]


def entities(pairs):
    i = 0
    while i < len(pairs) - 1 and not (pairs[i] == (0, "SECTION") and pairs[i + 1] == (2, "ENTITIES")):
        i += 1
    i += 2
    out = []
    while pairs[i] != (0, "ENDSEC"):
        if pairs[i][0] == 0:
            out.append([pairs[i]])
        else:
            out[-1].append(pairs[i])
        i += 1
    return out


def xdata(ent):
    """Danh sách chuỗi XDATA của ứng dụng COLREBAR."""
    out = []
    on = False
    for c, v in ent:
        if c == 1001:
            on = (v.strip() == APP)
        elif c == 1000 and on:
            out.append(v)
    return out


def vertices(ent):
    vs = []
    for c, v in ent:
        if c == 10:
            vs.append([float(v), 0.0, 0.0])
        elif c == 20 and vs:
            vs[-1][1] = float(v)
        elif c == 42 and vs:
            vs[-1][2] = float(v)
    return vs


def poly_length(vs):
    total = 0.0
    for a, b in zip(vs[:-1], vs[1:]):
        chord = math.hypot(b[0] - a[0], b[1] - a[1])
        bulge = a[2]
        if abs(bulge) > 1e-9 and chord > 0:
            theta = 4.0 * math.atan(abs(bulge))
            total += chord / (2.0 * math.sin(theta / 2.0)) * theta
        else:
            total += chord
    return total


def kv(parts):
    d = {}
    for p in parts[1:]:
        if "=" in p:
            k, v = p.split("=", 1)
            d[k] = v
    return d


def wt(d):
    return WT_K * d * d


def scan(path):
    cols = {}       # mark -> dict(SL, segs=[...])
    bars = []
    stirs = []
    for ent in entities(read_pairs(path)):
        t = ent[0][1]
        xs = xdata(ent)
        if not xs:
            continue
        head = xs[0].split("|")
        if t == "INSERT" and head[0] == "COL":
            info = kv(head)
            segs = []
            for line in xs[1:]:
                p = line.split("|")
                if p[0] == "SEG":
                    segs.append(dict(k=int(p[1]), n_from=p[2], n_to=p[3], H=float(p[4]),
                                     b=float(p[5]), h=float(p[6]), d=int(p[9]), stir=p[10],
                                     row=int(p[13]) if len(p) > 13 and p[13].isdigit() else None,
                                     round=(len(p) > 14 and p[14] == "C")))
            cols[info["M"]] = dict(SL=float(info.get("SL", 1)), segs=segs)
        elif t == "LWPOLYLINE" and head[0] == "BAR":
            i = kv(head)
            vs = vertices(ent)
            bars.append(dict(M=i["M"], SH=int(i["SH"]), D=int(i["D"]), N=int(i["N"]), SEG=int(i["SEG"]),
                             KIND=i["KIND"], LAP=float(i["LAP"]), L=poly_length(vs),
                             V=[(v[0], v[1]) for v in vs]))
        elif t == "LWPOLYLINE" and head[0] == "STIR":
            i = kv(head)
            stirs.append(dict(M=i["M"], SH=int(i["SH"]), D=int(i["D"]), SEG=int(i["SEG"]),
                              NUM=int(i["NUM"]), L=float(i["L"]), SP=int(i.get("SP", 0))))
    return cols, bars, stirs


def compute(cols, bars, stirs):
    rows = {}
    for c, info in cols.items():
        for s in info["segs"]:
            rows[(c, s["k"])] = dict(M=c, SEG=s["k"], n_from=s["n_from"], n_to=s["n_to"],
                                     doc=0.0, dai=0.0, noi=0.0, SL=info["SL"], row=s.get("row"))
    bydia = {}
    for b in bars:
        sl = cols.get(b["M"], {"SL": 1.0})["SL"]
        w = wt(b["D"])
        total = b["N"] * b["L"] / 1000.0 * w * sl
        noi = b["N"] * b["LAP"] / 1000.0 * w * sl
        r = rows.setdefault((b["M"], b["SEG"]), dict(M=b["M"], SEG=b["SEG"], n_from="", n_to="",
                                                      doc=0.0, dai=0.0, noi=0.0, SL=sl, row=None))
        r["doc"] += total - noi
        r["noi"] += noi
        d = bydia.setdefault(b["D"], [0.0, 0.0])
        d[0] += b["N"] * b["L"] / 1000.0 * sl
        d[1] += total
    for s in stirs:
        sl = cols.get(s["M"], {"SL": 1.0})["SL"]
        w = wt(s["D"])
        kg = s["NUM"] * s["L"] / 1000.0 * w * sl
        r = rows.setdefault((s["M"], s["SEG"]), dict(M=s["M"], SEG=s["SEG"], n_from="", n_to="",
                                                      doc=0.0, dai=0.0, noi=0.0, SL=sl, row=None))
        r["dai"] += kg
        d = bydia.setdefault(s["D"], [0.0, 0.0])
        d[0] += s["NUM"] * s["L"] / 1000.0 * sl
        d[1] += kg
    return [rows[k] for k in sorted(rows)], bydia


def write_csv(path, rows):
    with open(path, "w", encoding="utf-8-sig", newline="") as f:
        f.write("Pier;DongExcel;TangDau;TangCuoi;ThepDoc_Kg;ThepDai_Kg;ThepNoi_Kg;SLCK\n")
        for r in rows:
            f.write("%s;%s;%s;%s;%.2f;%.2f;%.2f;%g\n" % (r["M"], r["row"] if r["row"] else "", r["n_from"], r["n_to"],
                                                          r["doc"], r["dai"], r["noi"], r["SL"]))


def write_template(path, src_excel, rows):
    """Bảng kết quả đúng mẫu: sao chép sheet 'Column Detail' (tiêu đề, ô gộp, định dạng, dữ liệu nhập)
    từ file Excel nguồn và điền khối lượng (kg) vào cột AB (thép dọc), AC (thép đai), AD (thép nối)."""
    import warnings
    from copy import copy
    import openpyxl
    from openpyxl.utils import get_column_letter
    warnings.filterwarnings("ignore")
    src = openpyxl.load_workbook(src_excel, data_only=True)
    ws_s = src["Column Detail"]
    last = 8
    for r in range(9, ws_s.max_row + 1):
        if ws_s.cell(r, 1).value not in (None, ""):
            last = r
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Column Detail"
    for r in range(1, last + 1):
        for c in range(1, 31):
            sc = ws_s.cell(r, c)
            if sc.value is None and not sc.has_style:
                continue
            dc = ws.cell(r, c, value=sc.value)
            if sc.has_style:
                dc.font = copy(sc.font)
                dc.fill = copy(sc.fill)
                dc.border = copy(sc.border)
                dc.alignment = copy(sc.alignment)
                dc.number_format = sc.number_format
    for m in ws_s.merged_cells.ranges:
        if m.max_row <= last:
            ws.merge_cells(str(m))
    for k, dim in ws_s.column_dimensions.items():
        if dim.width:
            ws.column_dimensions[k].width = dim.width
    for r in range(1, last + 1):
        h = ws_s.row_dimensions[r].height
        if h:
            ws.row_dimensions[r].height = h
    ws.freeze_panes = ws_s.freeze_panes
    for r in rows:
        if not r.get("row"):
            continue
        for col, key in ((28, "doc"), (29, "dai"), (30, "noi")):
            c = ws.cell(r["row"], col, value=round(r[key], 2))
            c.number_format = "0.00"
    tr = last + 2
    ws.cell(tr, 1, value="TỔNG (kg)")
    for col in (28, 29, 30):
        L = get_column_letter(col)
        c = ws.cell(tr, col, value="=SUM(%s9:%s%d)" % (L, L, last))
        c.number_format = "0.00"
    wb.save(path)


def write_xlsx(path, rows, bydia):
    import openpyxl
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Boc tach"
    ws.append(["Cột", "Đoạn", "Tầng đầu", "Tầng cuối", "Thép dọc (kg)", "Thép đai (kg)", "Thép nối (kg)", "SL"])
    for r in rows:
        ws.append([r["M"], r["SEG"], r["n_from"], r["n_to"], round(r["doc"], 2), round(r["dai"], 2),
                   round(r["noi"], 2), r["SL"]])
    w2 = wb.create_sheet("Theo duong kinh")
    w2.append(["Đường kính (mm)", "Chiều dài (m)", "Khối lượng (kg)"])
    for d in sorted(bydia):
        w2.append([d, round(bydia[d][0], 2), round(bydia[d][1], 2)])
    wb.save(path)


def main():
    ap = argparse.ArgumentParser(description="Thống kê thép cột từ DXF")
    ap.add_argument("dxf")
    ap.add_argument("--csv", help="ghi kết quả theo đoạn ra CSV (UTF-8, dấu ;)")
    ap.add_argument("--xlsx", help="ghi kết quả ra file Excel mới")
    ap.add_argument("--mau", help="file Excel nguồn (có sheet Column Detail) để xuất bảng kết quả đúng mẫu")
    ap.add_argument("--xlsx-mau", help="file xuất bảng đúng mẫu (dùng cùng --mau)")
    a = ap.parse_args()
    cols, bars, stirs = scan(a.dxf)
    if not bars and not stirs:
        sys.exit("Không thấy dữ liệu COLREBAR trong file (cần file do excel_to_dxf.py sinh ra)")
    rows, bydia = compute(cols, bars, stirs)

    print("%-6s %-5s %-14s %12s %12s %12s %12s" % ("Pier", "Dòng", "Tầng", "Thép dọc Kg", "Thép đai Kg", "Thép nối Kg", "Cộng"))
    tot = [0.0, 0.0, 0.0]
    for r in rows:
        s = r["doc"] + r["dai"] + r["noi"]
        print("%-6s %-5s %-14s %12.2f %12.2f %12.2f %12.2f" % (
            r["M"], r["row"] or "", (r["n_from"] + "→" + r["n_to"]).strip("→"), r["doc"], r["dai"], r["noi"], s))
        tot[0] += r["doc"]; tot[1] += r["dai"]; tot[2] += r["noi"]
    print("%-6s %-4s %-12s %12.2f %12.2f %12.2f %12.2f" % ("TỔNG", "", "", tot[0], tot[1], tot[2], sum(tot)))
    print("\nTheo đường kính (đã nhân SL):")
    print("%-6s %14s %12s" % ("Ø", "Dài (m)", "Kg"))
    for d in sorted(bydia):
        print("%-6d %14.2f %12.2f" % (d, bydia[d][0], bydia[d][1]))
    print("\nChi tiết thanh dọc (chưa nhân SL):")
    print("%-5s %-4s %-4s %-4s %-6s %-5s %10s %10s" % ("Cột", "SH", "Ø", "SL/c", "Đoạn", "Loại", "Dài 1 thanh", "Nối"))
    for b in sorted(bars, key=lambda x: (x["M"], x["SH"])):
        print("%-5s %-4d %-4d %-4d %-6d %-5s %10.1f %10.1f" % (
            b["M"], b["SH"], b["D"], b["N"], b["SEG"], b["KIND"], b["L"], b["LAP"]))

    if a.csv:
        write_csv(a.csv, rows)
        print("\nĐã ghi", a.csv)
    if a.xlsx:
        write_xlsx(a.xlsx, rows, bydia)
        print("Đã ghi", a.xlsx)
    if a.mau and a.xlsx_mau:
        write_template(a.xlsx_mau, a.mau, rows)
        print("Đã ghi", a.xlsx_mau)


if __name__ == "__main__":
    main()
